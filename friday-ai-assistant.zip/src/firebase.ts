import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, initializeFirestore } from 'firebase/firestore';
import { getAnalytics, isSupported } from 'firebase/analytics';
import firebaseConfig from '../firebase-applet-config.json';

const configFromEnv = {
  apiKey: (import.meta as any).env?.VITE_FIREBASE_API_KEY,
  authDomain: (import.meta as any).env?.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: (import.meta as any).env?.VITE_FIREBASE_PROJECT_ID,
  storageBucket: (import.meta as any).env?.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: (import.meta as any).env?.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: (import.meta as any).env?.VITE_FIREBASE_APP_ID,
  measurementId: (import.meta as any).env?.VITE_FIREBASE_MEASUREMENT_ID,
  firestoreDatabaseId: (import.meta as any).env?.VITE_FIREBASE_DATABASE_ID,
};

// Use environment variables if present, otherwise fallback to the JSON file
const finalConfig = configFromEnv.apiKey ? { ...firebaseConfig, ...configFromEnv } : firebaseConfig;

const app = initializeApp(finalConfig);
console.log("Firebase initialized for project:", finalConfig.projectId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// Initialize Analytics if supported
export const analytics = isSupported().then(yes => yes ? getAnalytics(app) : null);

// Standard Firestore initialization with forced long polling for restricted iframe environments
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true // Resolves [code=unavailable] network errors
});

// Connection test
async function testConnection() {
  try {
    console.log("Friday is attempting to link with your cloud neural network...");
    // Attempting a simple read test
    const testDoc = await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Friday successfully linked with Cloud Firestore! Data access: ", testDoc.exists() ? "Active" : "Ready (Blank)");
  } catch (error: any) {
    // If we get permission-denied, it means we successfully reached the Firestore servers 
    // and the rules evaluated the request. This means we ARE online and connected!
    if (error.code === 'permission-denied') {
      console.log("Friday successfully linked with Cloud Firestore! (Rules verified connection)");
    } else if (error.message && error.message.includes('the client is offline')) {
      console.error("PROVISIONING ERROR: Firestore might not be created yet in asia-southeast1.");
    } else {
      console.warn("Friday neural link warning:", error.code);
      console.error("FIRESTORE ERROR DETAILS:", error.message);
    }
  }
}
testConnection();

export const loginWithEmail = (email: string, pass: string) => signInWithEmailAndPassword(auth, email, pass);
export const registerWithEmail = async (email: string, pass: string, name: string) => {
  const result = await createUserWithEmailAndPassword(auth, email, pass);
  await updateProfile(result.user, { displayName: name });
  return result;
};

export const loginWithGoogle = () => signInWithPopup(auth, googleProvider);

export const signOut = () => auth.signOut();
