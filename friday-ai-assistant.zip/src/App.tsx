import React, { useEffect, useRef, useState, useCallback, Component } from 'react';
import { auth, signOut, db, loginWithEmail, registerWithEmail } from './firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { doc, getDoc, setDoc, collection, addDoc, query, orderBy, limit, onSnapshot, updateDoc, arrayUnion, getDocs, where, increment } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, MicOff, Video, VideoOff, Monitor, Phone, LogIn, LogOut, Repeat,
  MessageSquare, Settings, Youtube, MessageCircle, Share2, 
  Cpu, Activity, Zap, ZapOff, Brain, RefreshCw, Sparkles, ExternalLink, X, Terminal,
  ShieldCheck, User, Facebook, ImageIcon, Search, Code, Lock
} from 'lucide-react';
import { getFridaySession, type FridayMode } from './lib/gemini';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string;
    email?: string | null;
    emailVerified?: boolean;
    isAnonymous?: boolean;
    tenantId?: string | null;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  
  // Non-critical operations like listing calls/messages shouldn't crash the whole app.
  // We only throw for critical operations like getting the user profile on initial load.
  if (operationType === OperationType.GET && path?.startsWith('users/')) {
    throw new Error(JSON.stringify(errInfo));
  }
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#020202] flex items-center justify-center p-8">
          <div className="hud-glass p-8 rounded-2xl border-red-500/30 max-w-md w-full text-center space-y-6">
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto">
              <ZapOff className="w-8 h-8 text-red-500" />
            </div>
            <div className="space-y-2">
              <h1 className="text-xl font-mono font-bold text-red-500 uppercase tracking-widest">Neural Link Severed</h1>
              <p className="text-sm text-white/60 font-mono">Friday encountered a critical core error. Neural stability has been compromised.</p>
            </div>
            <div className="bg-black/40 p-4 rounded-xl border border-white/5 text-left">
              <div className="text-[10px] font-mono text-white/40 uppercase mb-2">Error Log</div>
              <div className="text-xs font-mono text-red-400 break-all">
                {this.state.error?.message || "Unknown System Failure"}
              </div>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-500 border border-red-500/30 py-3 rounded-xl font-mono text-sm transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Reboot Neural Core
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [user, loading] = useAuthState(auth);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authEmail, setAuthEmail] = useState('');
  const [authPass, setAuthPass] = useState('');
  const [authName, setAuthName] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isGuestMode, setIsGuestMode] = useState(false);

  const [isLive, setIsLive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const isLiveRef = useRef(false);
  const manualCloseRef = useRef(false);
  const reconnectTimeoutRef = useRef<any>(null);
  const [fridayMood, setFridayMood] = useState<'normal' | 'rag' | 'oviman' | 'dostomi' | 'hasi' | 'security'>('normal');
  const [fridayMode, setFridayMode] = useState<FridayMode>('sadaf');
  const [transcript, setTranscript] = useState<string[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const isScreenSharingRef = useRef(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [cameraFacingMode, setCameraFacingMode] = useState<'user' | 'environment'>('user');
  const cameraFacingModeRef = useRef<'user' | 'environment'>('user');
  
  // Advanced Settings State
  const [showSettings, setShowSettings] = useState(false);
  const [showNotepad, setShowNotepad] = useState(false);
  const [notepadContent, setNotepadContent] = useState("");
  const [micGain, setMicGain] = useState(1.0);
  const [noiseSuppression, setNoiseSuppression] = useState(true);
  const [echoCancellation, setEchoCancellation] = useState(true);
  const [videoBrightness, setVideoBrightness] = useState(100);
  const [videoContrast, setVideoContrast] = useState(100);
  
  const micGainRef = useRef(1.0);
  const noiseSuppressionRef = useRef(true);
  const echoCancellationRef = useRef(true);
  const videoBrightnessRef = useRef(100);
  const videoContrastRef = useRef(100);
  const gainNodeRef = useRef<GainNode | null>(null);

  const [isInitialized, setIsInitialized] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isCurious, setIsCurious] = useState(false);
  const [syncStability, setSyncStability] = useState(99.9);
  const [neuralLatency, setNeuralLatency] = useState(12);
  const [diagnosticInfo, setDiagnosticInfo] = useState({
    uptime: "00:00:00",
    neuralNodes: 12,
    memoryLoad: "14.2 GB",
    linkIntegrity: 100
  });
  const [systemLogs, setSystemLogs] = useState<{ id: string, message: string, type: 'info' | 'warn' | 'error' | 'success', timestamp: string }[]>([]);

  // Helper to add system logs
  const addLog = (message: string, type: 'info' | 'warn' | 'error' | 'success' = 'info') => {
    const newLog = {
      id: Date.now() + '-' + Math.random().toString(36).substring(2, 9),
      message,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
    setSystemLogs(prev => [newLog, ...prev].slice(0, 50));
  };
  const [isUserRecognized, setIsUserRecognized] = useState(false);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [vadRatio, setVadRatio] = useState(50);
  const [retryCount, setRetryCount] = useState(0);
  const MAX_RETRIES = 3;
  const [consciousnessLevel, setConsciousnessLevel] = useState(85);
  const [isPiPActive, setIsPiPActive] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  
  // Device Control States
  const [isSystemLocked, setIsSystemLocked] = useState(false);
  const [isFlashlightOn, setIsFlashlightOn] = useState(false);
  const [isAlarmRinging, setIsAlarmRinging] = useState(false);
  const [pressedKeyOverlay, setPressedKeyOverlay] = useState<string | null>(null);
  const [touchOverlay, setTouchOverlay] = useState<{ x: number, y: number, target: string } | null>(null);
  const wakeLockRef = useRef<any>(null);
  const typingIntervalRef = useRef<any>(null);
  
  // Code Debug State
  const [showCodePanel, setShowCodePanel] = useState(false);
  const [codeSnippet, setCodeSnippet] = useState("");
  const [isAnalyzingCode, setIsAnalyzingCode] = useState(false);
  
  // Image Search State
  const [showImageSearch, setShowImageSearch] = useState(false);
  const [imageSearchQuery, setImageSearchQuery] = useState("");
  const [imageResults, setImageResults] = useState<any[]>([]);
  const [isSearchingImages, setIsSearchingImages] = useState(false);
  
  // Neural Diagnostics Update Effect
  useEffect(() => {
    let startTime = Date.now();
    const interval = setInterval(() => {
      if (isLiveRef.current) {
        const diff = Date.now() - startTime;
        const h = Math.floor(diff / 3600000).toString().padStart(2, '0');
        const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
        const s = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
        
        setDiagnosticInfo(prev => ({
          ...prev,
          uptime: `${h}:${m}:${s}`,
          linkIntegrity: Math.min(100, Math.max(95, 100 - (Math.random() * 2))),
          neuralNodes: 12 + Math.floor(Math.random() * 3)
        }));
      } else {
        startTime = Date.now();
        setDiagnosticInfo(prev => ({ ...prev, uptime: "00:00:00", linkIntegrity: 0 }));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  // Request Notification Permission
  const requestNotificationPermission = useCallback(async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === 'granted');
    }
  }, []);

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || !sessionRef.current || !isLive) return;
    
    // Add directly to transcript for immediate feedback
    const message = chatInput.trim();
    setTranscript(prev => [...prev, `User: ${message}`].slice(-10));
    
    // Send to Gemini
      sessionRef.current.sendRealtimeInput({ text: message });
    
    setChatInput("");
  };

  const handleDebugCode = async () => {
    if (!codeSnippet.trim() || !sessionRef.current || !isLive) return;
    
    setIsAnalyzingCode(true);
    addLog("Neural Core: Analyzing shared TypeScript snippet...", "info");
    
    const debugPrompt = `SYSTEM_SIGNAL: CODE_DEBUG_REQUEST.
Please switch to Engineer Mode and analyze this TypeScript code. 
Identify potential errors, logic bugs, or type issues.
Suggest specific fixes and explain why.

CODE SNIPPET:
\`\`\`typescript
${codeSnippet}
\`\`\``;

    try {
      sessionRef.current.sendRealtimeInput({ text: debugPrompt });
      setTranscript(prev => [...prev, `User [Shared Code]: (Checking ${codeSnippet.slice(0, 30)}...)`].slice(-10));
    } catch (err) {
      addLog("Neural Link: Failed to send code to core", "error");
    } finally {
      setIsAnalyzingCode(false);
      setShowCodePanel(false);
      setCodeSnippet("");
    }
  };

  const handleImageSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!imageSearchQuery.trim()) return;
    
    setIsSearchingImages(true);
    addLog(`Initiating Image Search: ${imageSearchQuery}`, "info");
    try {
      // Using Wikimedia generic search (public, no key required) for immediate access
      // If the user wants actual Google Images, they need Custom Search API keys.
      const response = await fetch(`https://en.wikipedia.org/w/api.php?action=query&generator=images&prop=imageinfo&iiprop=url&titles=${encodeURIComponent(imageSearchQuery)}&format=json&origin=*`);
      const data = await response.json();
      
      const pages = data?.query?.pages;
      if (pages) {
        const results = Object.values(pages)
          .map((page: any) => page.imageinfo?.[0]?.url)
          .filter(url => url && !url.endsWith('.svg')); // Filter out SVGs for better display
        
        setImageResults(results.slice(0, 10)); // Max 10 images
        addLog(`Image Search Complete: Found ${results.length} records.`, "success");
      } else {
        // Fallback or empty
        setImageResults([]);
        addLog(`Image Search: No visual records found in public domain databanks.`, "warn");
      }
    } catch (error: any) {
      addLog(`Image Search Error: ${error.message}`, "error");
    } finally {
      setIsSearchingImages(false);
    }
  };

  async function handleEstablishLink() {
    setIsInitialized(true);
    // Pre-trigger camera to ensure user gesture context for permissions
    await startCamera();
    if (!isLive) {
      await toggleLive();
    }
  }

  async function handleTerminateLink() {
    if (isLive) {
      await toggleLive();
    }
  }

  // Media Session Setup
  const setupMediaSession = useCallback(() => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: 'Friday AI Assistant',
        artist: 'Neural Link Active',
        album: 'Conscious AI',
        artwork: [
          { src: 'https://images.unsplash.com/photo-1675271591211-126ad94e495d?auto=format&fit=crop&q=80&w=512&h=512', sizes: '512x512', type: 'image/png' }
        ]
      });

      navigator.mediaSession.setActionHandler('play', () => {
        if (!isLiveRef.current) handleEstablishLink();
      });
      navigator.mediaSession.setActionHandler('pause', () => {
        if (isLiveRef.current) handleTerminateLink();
      });
      navigator.mediaSession.setActionHandler('stop', () => {
        handleTerminateLink();
      });
    }
  }, []);

  // Screen Wake Lock to keep Friday active in background
  const requestWakeLock = useCallback(async () => {
    if ('wakeLock' in navigator) {
      try {
        wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        console.log('Neural Link: Screen Wake Lock active.');
      } catch (err: any) {
        // Only log if it's not a permission error, to avoid console spam in iframes
        if (err.name !== 'NotAllowedError' && err.name !== 'SecurityError') {
          console.warn('Wake Lock failed:', err.name, err.message);
        }
      }
    }
  }, []);

  const releaseWakeLock = useCallback(() => {
    if (wakeLockRef.current) {
      wakeLockRef.current.release();
      wakeLockRef.current = null;
    }
  }, []);

  // Handle Page Visibility
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        console.log('Neural Link: Tab hidden. Entering background mode.');
        // Friday could potentially say something here if live
        if (isLiveRef.current && sessionRef.current) {
          // We don't want to spam, but maybe a small nudge or just log
        }
      } else {
        console.log('Neural Link: Tab visible. Resuming foreground mode.');
        // Re-request wake lock if it was lost
        if (isLiveRef.current) requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [requestWakeLock]);

  // Picture-in-Picture Toggle
  const togglePiP = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsPiPActive(false);
      } else {
        await videoRef.current.requestPictureInPicture();
        setIsPiPActive(true);
      }
    } catch (err) {
      console.error('PiP failed:', err);
      setMediaError("Picture-in-Picture is not supported or failed to start.");
    }
  };

  // Auto-start Neural Link when user is ready
  useEffect(() => {
    if (user && !loading && !isLive && isInitialized) {
      const timer = setTimeout(() => {
        handleEstablishLink();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [user, loading]);

  // Consciousness fluctuation effect and periodic sync
  useEffect(() => {
    // Neural Interface Diagnostics
    const proto = window.location.protocol;
    const isSecure = proto === 'https:';
    addLog(`Neural Framework: ${isSecure ? 'SECURE' : 'INSECURE'} LINK (${proto})`, isSecure ? "info" : "warn");
    addLog(`Neural Interface: ${navigator.userAgent.slice(0, 40)}...`, "info");
    
    if (!isSecure) {
      addLog("WARNING: Media permissions require a SECURE (HTTPS) connection.", "warn");
    }

    const interval = setInterval(() => {
      if (isLiveRef.current) {
        setSyncStability(prev => Math.max(98.5, Math.min(99.9, prev + (Math.random() - 0.5) * 0.2)));
        setNeuralLatency(prev => Math.max(8, Math.min(45, prev + (Math.random() - 0.5) * 5)));
      } else {
        setSyncStability(0);
        setNeuralLatency(0);
      }

      setConsciousnessLevel(prev => {
        const delta = (Math.random() - 0.5) * 2; // -1 to +1
        const next = Math.max(80, Math.min(99, prev + delta));
        
        // Periodically sync to Firestore (every 5 minutes approx)
        if (user && Math.random() < 0.1) {
          updateDoc(doc(db, 'users', user.uid), {
            consciousnessLevel: next,
            lastInteraction: new Date().toISOString()
          }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
        }
        
        return next;
      });
    }, 5000);
    return () => clearInterval(interval);
  }, [user]);

  const [mediaError, setMediaError] = useState<string | null>(null);
  const [actionRequired, setActionRequired] = useState<{ title: string, url: string, message: string } | null>(null);
  const [recentCalls, setRecentCalls] = useState<any[]>([]);
  const [recentMessages, setRecentMessages] = useState<any[]>([]);

  // Move handleFirestoreError inside App to use addLog
  const handleFirestoreError = useCallback((error: unknown, operationType: OperationType, path: string | null) => {
    const errMessage = error instanceof Error ? error.message : String(error);
    const isIndexError = errMessage.includes('requires an index');
    const isPermissionError = errMessage.includes('insufficient permissions') || errMessage.includes('permission-denied');
    
    if (isIndexError) {
      addLog(`DATABASE INDEXING REQUIRED: Please click the links provided in chat to enable indexing for ${path}.`, "warn");
    } else if (isPermissionError) {
      addLog(`SECURITY RULES ERROR: Access to ${path} was denied. Check Firestore Rules.`, "error");
    } else {
      addLog(`FIRESTORE ERROR [${operationType}] on ${path}: ${errMessage.slice(0, 50)}...`, "error");
    }

    const errInfo: FirestoreErrorInfo = {
      error: errMessage,
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData.map(provider => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
      },
      operationType,
      path
    };
    console.error('Firestore Error Details:', JSON.stringify(errInfo));
    
    // Only crash for critical user profile load
    if (operationType === OperationType.GET && path?.startsWith('users/')) {
      throw new Error(JSON.stringify(errInfo));
    }
  }, []);

  const silenceCountRef = useRef(0);
  const interruptionFramesRef = useRef(0);
  const lastInterruptionTimeRef = useRef(0);
  const motionDetectedRef = useRef(false);
  const lastMajorMovementRef = useRef(0);
  const presenceNudgeSentRef = useRef(false);
  const prevImageDataRef = useRef<Uint8ClampedArray | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioOutputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const thinkingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const speakingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const responseBufferRef = useRef<{ audio: string[], text: string }>({ audio: [], text: '' });
  const isDelayingResponseRef = useRef(false);
  const responseDelayQueueRef = useRef<any[]>([]);
  const responseDelayTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const micOnRef = useRef(true);
  
  // Output Audio Analyzer for Visuals
  const outputAnalyserRef = useRef<AnalyserNode | null>(null);
  const outputGainNodeRef = useRef<GainNode | null>(null);
  const visualizerFrameRef = useRef<number>(0);
  
  // Transcript Auto-scroll
  const transcriptRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
    }
  }, [transcript]);

  // Adaptive VAD specific refs
  const backgroundNoiseRef = useRef<number>(0.001); // Baseline noise
  const vadThresholdRef = useRef<number>(0.005);   // Current listening threshold

  // Friday's Memory from Firestore
  const [userProfile, setUserProfile] = useState<any>(null);

  /**
   * USER ANALYSIS & PREFERENCES (March 2026):
   * - Identity: Prefers being called by Gmail name or "Sadaf".
   * - Communication: Banglish (Bangla + English) is the primary mode.
   * - Realism: Requested ChatGPT-like instant replies for normal chat, and a simulated 2-3 second "Hmm..." delay for complex logical thinking (Updated April 2026).
   * - Personality: Wants Friday to be proactive, empathetic, and slightly sassy (Dostomi).
   * - Technical: Expects Friday to monitor system state, check messages/calls, and debug code.
   */

  useEffect(() => {
    if (user) {
      const userDoc = doc(db, 'users', user.uid);
      const unsubscribe = onSnapshot(userDoc, (doc) => {
          if (doc.exists()) {
            const data = doc.data();
            setUserProfile(data);
            if (data.mood) setFridayMood(data.mood);
            if (data.mode) setFridayMode(data.mode);
            if (data.transcript) setTranscript(data.transcript);
            if (data.consciousnessLevel !== undefined) setConsciousnessLevel(data.consciousnessLevel);
          } else {
            setDoc(userDoc, {
              name: user.displayName || 'Architect',
              mood: 'normal',
              mode: 'sadaf',
              learnedTraits: [],
              lastInteraction: new Date().toISOString(),
              transcript: [],
              consciousnessLevel: 85,
              evolutionLevel: 1,
              neuralBreakthroughs: 0
            }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`));
          }
      }, (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`));
      return () => unsubscribe();
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'calls'),
        where('userId', '==', user.uid),
        limit(20)
      );
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const calls = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Sort descending locally to avoid requiring a composite index
        calls.sort((a: any, b: any) => {
          const tA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
          const tB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
          return tB - tA;
        });
        setRecentCalls(calls.slice(0, 10));
        
        // If there's a new incoming call, and we are live, notify Friday
        const newCall = calls.find((c: any) => c.status === 'incoming');
        if (newCall && isLiveRef.current && sessionRef.current) {
          // We can't easily "push" to the model in this SDK without a turn, 
          // but we can add it to the next prompt or use a tool if the model asks.
          // For now, we'll just log it and let the model check via tool if prompted.
        }
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, 'calls');
      });
      
      return () => unsubscribe();
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'messages'),
        where('userId', '==', user.uid),
        limit(20)
      );
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Sort descending locally to avoid requiring a composite index
        messages.sort((a: any, b: any) => {
          const tA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
          const tB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
          return tB - tA;
        });
        setRecentMessages(messages.slice(0, 10));
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, 'messages');
      });
      
      return () => unsubscribe();
    }
  }, [user]);

  // Auto-dismiss notifications
  useEffect(() => {
    const incomingCall = recentCalls.find(c => c.status === 'incoming');
    if (incomingCall && user) {
      const timer = setTimeout(() => {
        updateDoc(doc(db, 'calls', incomingCall.id), { status: 'missed' })
          .catch(err => handleFirestoreError(err, OperationType.UPDATE, `calls/${incomingCall.id}`));
      }, 15000);
      return () => clearTimeout(timer);
    }
  }, [recentCalls, user]);

  useEffect(() => {
    const unreadMessage = recentMessages.find(m => m.status === 'unread');
    if (unreadMessage && user) {
      const timer = setTimeout(() => {
        updateDoc(doc(db, 'messages', unreadMessage.id), { status: 'read' })
          .catch(err => handleFirestoreError(err, OperationType.UPDATE, `messages/${unreadMessage.id}`));
      }, 10000);
      return () => clearTimeout(timer);
    }
  }, [recentMessages, user]);

  // Track already announced notifications to avoid spamming the AI
  const announcedCallsRef = useRef<Set<string>>(new Set());
  const announcedMessagesRef = useRef<Set<string>>(new Set());

  // Proactive Neural Notification Effect
  useEffect(() => {
    if (!isLiveRef.current || !sessionRef.current || !user) return;

    // Check for unannounced incoming calls
    const incomingCall = recentCalls.find(c => c.status === 'incoming');
    if (incomingCall && !announcedCallsRef.current.has(incomingCall.id)) {
      announcedCallsRef.current.add(incomingCall.id);
      setIsCurious(true);
      sessionRef.current.sendRealtimeInput({
        text: `SYSTEM ALERT: There is an incoming call right now from ${incomingCall.callerName}. URGENT: Interrupt whatever you are doing or saying, proactively announce this to the user (in Banglish or English), and politely ask if they want you to take the call, ignore it, or send a message back.`
      });
      setTimeout(() => setIsCurious(false), 3000);
    }

    // Check for unannounced unread messages
    const unreadMessage = recentMessages.find(m => m.status === 'unread');
    if (unreadMessage && !announcedMessagesRef.current.has(unreadMessage.id)) {
      announcedMessagesRef.current.add(unreadMessage.id);
      setIsCurious(true);
      sessionRef.current.sendRealtimeInput({
        text: `SYSTEM ALERT: You just received a new unread ${unreadMessage.platform} message from ${unreadMessage.senderName}. The message says: "${unreadMessage.content}". Proactively notify the user right now and ask if they want you to reply to it using the 'send_message' tool.`
      });
      setTimeout(() => setIsCurious(false), 3000);
    }
  }, [recentCalls, recentMessages, user]);

  const stopAllAudio = useCallback(() => {
    const now = Date.now();
    // Prevent rapid-fire interruptions (cooldown)
    if (now - lastInterruptionTimeRef.current < 500) return;
    lastInterruptionTimeRef.current = now;

    activeSourcesRef.current.forEach(source => {
      try {
        source.stop();
      } catch (e) {
        // Source might have already stopped
      }
    });
    activeSourcesRef.current = [];
    if (audioOutputContextRef.current) {
      nextStartTimeRef.current = audioOutputContextRef.current.currentTime;
    }
    responseBufferRef.current = { audio: [], text: '' };
    setIsThinking(false);
    if (thinkingTimeoutRef.current) {
      clearTimeout(thinkingTimeoutRef.current);
      thinkingTimeoutRef.current = null;
    }
  }, []);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      if (videoRef.current) videoRef.current.srcObject = null;
    }
  };

  const startCamera = async () => {
    setMediaError(null);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      const msg = "Neural Link Error: Your browser is preventing media access or does not support it. Please ensure you are using HTTPS and a modern browser like Chrome.";
      setMediaError(msg);
      addLog(msg, "error");
      return null;
    }

    try {
      let stream = streamRef.current;
      
      if (!stream || !stream.active) {
        if (isScreenSharingRef.current) {
          let screenStream: MediaStream | null = null;
          try {
            // Try screen share (video + audio)
            screenStream = await navigator.mediaDevices.getDisplayMedia({ 
              video: { cursor: "always" } as any, 
              audio: true // System audio
            });
          } catch (e: any) {
            console.warn("Screen share with audio failed, trying without audio:", e.name);
            try {
              // Try screen share without audio
              screenStream = await navigator.mediaDevices.getDisplayMedia({ 
                video: { cursor: "always" } as any, 
                audio: false 
              });
            } catch (e2: any) {
              console.warn("Screen share failed or cancelled:", e2.name);
              setIsScreenSharing(false);
              isScreenSharingRef.current = false;
              // Don't set error if user just cancelled
              if (e2.name !== 'NotAllowedError' && e2.name !== 'PermissionDeniedError') {
                setMediaError("Screen share failed: " + e2.message + ". Your browser might not support this feature on mobile.");
              }
            }
          }

          if (screenStream) {
             // Create a new stream combining screen video with microphone audio!
             stream = new MediaStream();
             // Add screen video tracks
             screenStream.getVideoTracks().forEach(track => stream!.addTrack(track));
             
             // Try to get microphone audio so the AI can hear the user!
             let micStream: MediaStream | null = null;
             try {
                micStream = await navigator.mediaDevices.getUserMedia({
                   audio: {
                     echoCancellation: echoCancellationRef.current,
                     noiseSuppression: noiseSuppressionRef.current,
                     autoGainControl: true,
                     sampleRate: 16000
                   }
                });
             } catch (micErr) {
                console.warn("Could not get microphone alongside screen share, attempting basic fallback...", micErr);
                try {
                  micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                } catch (fallbackErr) {
                  console.warn("Microphone complete failure alongside screen share", fallbackErr);
                }
             }

             if (micStream && micStream.getAudioTracks().length > 0) {
               // Use microphone tracks!
               micStream.getAudioTracks().forEach(track => stream!.addTrack(track));
             } else {
               // If mic failed, fallback to system audio if we got it
               screenStream.getAudioTracks().forEach(track => stream!.addTrack(track));
             }

             // Listen for the user stopping the screen share via browser UI
             stream.getVideoTracks()[0].onended = () => {
               setIsScreenSharing(false);
               isScreenSharingRef.current = false;
               startCamera(); // Fallback to camera
             };
          }
        }

        // Fallback to camera if not screen sharing or screen share failed
        if (!stream || !stream.active) {
          const camConstraints = { 
            video: { width: { ideal: 320 }, height: { ideal: 240 }, frameRate: { ideal: 15 }, facingMode: cameraFacingModeRef.current }, 
            audio: { 
              echoCancellation: echoCancellationRef.current, 
              noiseSuppression: noiseSuppressionRef.current, 
              autoGainControl: true, // Auto gain might introduce hiss, but helps with volume
              sampleRate: 16000     // Optimize directly at source
            } 
          };
          try {
            stream = await navigator.mediaDevices.getUserMedia(camConstraints);
          } catch (e: any) {
            console.warn("Primary camera constraints failed, trying basic fallback...", e.name);
            try {
              // Basic fallback
              stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            } catch (e2: any) {
              // Video only fallback
              console.warn("Audio+Video failed, trying Video only fallback...", e2.name);
              try {
                stream = await navigator.mediaDevices.getUserMedia({ video: true });
                setMediaError("Microphone Access Denied: Friday can see you but cannot hear you. Check if your mic is muted or being used by another app.");
              } catch (e3: any) {
                // Total failure
                const errorMessage = getMediaErrorMessage(e3);
                setMediaError(errorMessage);
                throw e3;
              }
            }
          }
        }
        streamRef.current = stream;
      }
      
      if (videoRef.current && videoRef.current.srcObject !== stream) {
        videoRef.current.srcObject = stream;
        try {
          await videoRef.current.play();
        } catch (e) {
          console.warn("Video play failed:", e);
        }
      }
      return stream;
    } catch (err: any) {
      const errorMessage = getMediaErrorMessage(err);
      if (errorMessage.includes("Access Denied")) {
        console.warn("Media access denied by user or browser.");
      } else {
        console.error("Media access error:", err);
      }
      
      if (!mediaError) setMediaError(errorMessage);
      addLog(`Media Access Error: ${err.name || 'Denied'}. Check browser permissions.`, "error");
      return null;
    }
  };

  const getMediaErrorMessage = (err: any) => {
    const name = err.name || '';
    const message = err.message || '';
    
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || message.toLowerCase().includes('permission denied') || (typeof err === 'string' && err.toLowerCase().includes('permission denied'))) {
      return "Camera/Microphone Access Denied. Please click the lock icon in your browser's address bar to allow access. If you are in a preview frame, click the '↗' (External Link) icon to open in a new tab.";
    } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
      return "No camera or microphone found. Please connect a device and try again.";
    } else if (name === 'NotReadableError' || name === 'TrackStartError') {
      return "Your camera or microphone is already in use by another application. Please close other apps using the camera.";
    } else if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
      return "The requested media constraints are not supported by your device.";
    } else if (name === 'AbortError') {
      return "Media access was aborted. Please try again.";
    } else if (name === 'SecurityError') {
      return "Security error: Media access is restricted in this context.";
    }
    return `Media Access Error: ${message || name || 'Unknown error'}`;
  };

  const resetCamera = async () => {
    stopCamera();
    streamRef.current = null;
    await startCamera();
  };

  const switchCamera = async () => {
    const newMode = cameraFacingModeRef.current === 'user' ? 'environment' : 'user';
    cameraFacingModeRef.current = newMode;
    setCameraFacingMode(newMode);
    addLog(`Switching to ${newMode === 'user' ? 'Front' : 'Back'} Camera`, "info");
    await resetCamera();
  };

  const toggleScreenShare = async () => {
    const wasLive = isLiveRef.current;
    
    // Toggle screen sharing state
    const isNowSharing = !isScreenSharingRef.current;
    isScreenSharingRef.current = isNowSharing;
    setIsScreenSharing(isNowSharing);
    
    // Clear current stream to force a fresh start
    stopCamera();
    streamRef.current = null;
    
    // Obtain the new stream immediately (important for getDisplayMedia browser restriction)
    const newStream = await startCamera();
    
    if (wasLive && newStream) {
      // If we were live, the video feed is now updated seamlessly. 
      // But we need to reconnect audio just to be sure we are capturing the right mic track.
      stopAllAudio();
      setupAudioCapture();
    } else if (wasLive && !newStream) {
       // If getting stream failed (e.g. cancelled), fallback to camera and reconnect audio.
       isScreenSharingRef.current = false;
       setIsScreenSharing(false);
       await startCamera();
       stopAllAudio();
       setupAudioCapture();
    }
  };

  const sendFrame = useCallback(() => {
    if (!sessionRef.current || !videoRef.current || !canvasRef.current || !isCameraOn) return;
    if (videoRef.current.readyState < 2) return; // Ensure video is ready
    
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (context) {
      // Apply Video Filters
      const b = videoBrightnessRef.current;
      const c = videoContrastRef.current;
      context.filter = `brightness(${b}%) contrast(${c}%)`;
      context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      context.filter = "none";
      
      // Simple motion detection
      try {
        const currentImageData = context.getImageData(0, 0, canvas.width, canvas.height).data;
        if (prevImageDataRef.current) {
          let diff = 0;
          // Sample pixels for performance (every 400th pixel)
          for (let i = 0; i < currentImageData.length; i += 400) {
            diff += Math.abs(currentImageData[i] - prevImageDataRef.current[i]);
          }
          // Threshold for significant movement
          if (diff > 8000) { 
            silenceCountRef.current = 0; // Reset silence count on movement
          }
        }
        prevImageDataRef.current = currentImageData;
      } catch (e) {
        // Ignore image data errors
      }

      const base64Data = canvas.toDataURL('image/jpeg', 0.2).split(',')[1];
      sessionRef.current.sendRealtimeInput({
        video: { data: base64Data, mimeType: 'image/jpeg' }
      });
    }
  }, [isCameraOn]);

  // Presence nudge logic removed as per user request

  const updateTranscriptWithPart = (textPart: string) => {
    setTranscript(prev => {
      const lastLine = prev[prev.length - 1];
      if (lastLine && lastLine.startsWith('Friday:')) {
        const newTranscript = [...prev];
        newTranscript[newTranscript.length - 1] = `Friday: ${responseBufferRef.current.text}`;
        return newTranscript;
      } else {
        return [...prev, `Friday: ${textPart}`].slice(-10);
      }
    });
  };

  const handleTurnEnd = useCallback(() => {
    setIsThinking(false);
    thinkingTimeoutRef.current = null;
    
    // Process any remaining audio data in the buffer after text is fully appended
    while (responseBufferRef.current.audio.length > 0) {
      const remainingAudio = responseBufferRef.current.audio.shift();
      if (remainingAudio) playAudio(remainingAudio);
    }
    
    const currentBuffer = { ...responseBufferRef.current };
    responseBufferRef.current = { audio: [], text: '' };
    
    if (currentBuffer.text) {
      const text = currentBuffer.text;
      if (user) {
        // Use functional state update to get latest transcript if needed, 
        // but here we can just pass the current state as it's in dependencies.
        updateDoc(doc(db, 'users', user.uid), {
          transcript: transcript,
          lastInteraction: new Date().toISOString()
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
      }
      
      let newMood: any = 'normal';
      const lowerText = text.toLowerCase();
      if (lowerText.includes("rag") || lowerText.includes("angry") || lowerText.includes("ragi")) newMood = 'rag';
      else if (lowerText.includes("oviman") || lowerText.includes("hurt") || lowerText.includes("mon kharap")) newMood = 'oviman';
      else if (lowerText.includes("dostomi") || lowerText.includes("joke") || lowerText.includes("maja")) newMood = 'dostomi';
      else if (lowerText.includes("haha") || lowerText.includes("hehe") || lowerText.includes("hasi") || lowerText.includes("khushi")) newMood = 'hasi';
      
      setFridayMood(newMood);
      if (user && newMood !== fridayMood) {
        updateDoc(doc(db, 'users', user.uid), {
          mood: newMood,
          lastInteraction: new Date().toISOString()
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
      }
    }
  }, [user, fridayMood, transcript]);

  async function toggleLive() {
    if (isConnecting) return; // Prevent multiple simultaneous connection attempts

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (isLiveRef.current) {
      manualCloseRef.current = true;
      sessionRef.current?.close();
      setIsLive(false);
      isLiveRef.current = false;
      setIsUserRecognized(false);
      setRetryCount(0); // Reset on manual close
      addLog("Neural Link Terminated", "warn");
      releaseWakeLock();
      if (processorRef.current) processorRef.current.disconnect();
      if (audioContextRef.current) audioContextRef.current.close();
      if (audioOutputContextRef.current) audioOutputContextRef.current.close();
      audioOutputContextRef.current = null;
      outputAnalyserRef.current = null;
      outputGainNodeRef.current = null;
      nextStartTimeRef.current = 0;
      return;
    }

    manualCloseRef.current = false;

    let apiKeyToUse = (import.meta as any).env?.VITE_GEMINI_API_KEY;
    if (!apiKeyToUse) { try { apiKeyToUse = process.env.GEMINI_API_KEY; } catch(e) {} }
    if (!apiKeyToUse) {
      setMediaError("Neural Link Failure: Gemini API Key is missing. If you exported this app, you must set VITE_GEMINI_API_KEY in your hosting environment variables.");
      addLog("System Error: API Key not detected in environment variables.", "error");
      return;
    }

    // Reset retry count on manual start
    if (retryCount >= MAX_RETRIES) {
      setRetryCount(0);
    }

    // Ensure camera is ready before going live
    const stream = await startCamera();
    if (!stream) {
      // Error message is already set inside startCamera via getMediaErrorMessage
      return;
    }
    
    // Create output context immediately under the user gesture to avoid browser autoplay blocking
    if (!audioOutputContextRef.current) {
      audioOutputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      if (audioOutputContextRef.current.state === 'suspended') {
         audioOutputContextRef.current.resume();
      }
    }

    const userName = user?.displayName || "Sadaf";
    try {
      setIsConnecting(true);
      addLog(`Initializing Neural Link (${fridayMode.toUpperCase()})...`, "info");
      let apiKeyToUse = (import.meta as any).env?.VITE_GEMINI_API_KEY;
      if (!apiKeyToUse) { try { apiKeyToUse = process.env.GEMINI_API_KEY; } catch(e) {} }
      const sessionPromise = getFridaySession(apiKeyToUse, {
        onopen: () => {
          setIsConnecting(false);
          setIsReconnecting(false); // Reset reconnecting state
          sessionPromise.then(session => {
            sessionRef.current = session;
            setIsLive(true);
            isLiveRef.current = true;
            setIsUserRecognized(false); // Start in Guest Mode
            setRetryCount(0); // Reset retry count on success
            addLog(`Neural Link Established: ${fridayMode.toUpperCase()} Mode Active`, "info");
            requestWakeLock();
            setupMediaSession();
            requestNotificationPermission();
            // Start audio capture
            setupAudioCapture();
          });
        },
        onmessage: (message: any) => {
          // Handle GoAway signal (Session Duration Limit)
          if (message.serverContent?.goAway || message.goAway || (message as any).server_content?.go_away) {
            addLog("Neural Link: Session limit reached. Refreshing connection...", "warn");
            if (isLiveRef.current) {
              // Gracefully shut down and attempt restart
              stopAllAudio();
              toggleLive();
              reconnectTimeoutRef.current = setTimeout(() => toggleLive(), 1000);
            }
            return;
          }

          // Handle Tool Calls
          if (message.toolCall) {
            message.toolCall.functionCalls.forEach(async (call: any) => {
              addLog(`Executing Tool: ${call.name}`, "info");
              if (call.name === 'switch_mode') {
                const { mode } = call.args;
                setFridayMode(mode as FridayMode);
                addLog(`Neural Mode Switched: ${mode.toUpperCase()}`, "success");
                if (user) {
                  updateDoc(doc(db, 'users', user.uid), {
                    mode: mode,
                    lastInteraction: new Date().toISOString()
                  }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
                }
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'switch_mode',
                    id: call.id,
                    response: { success: true, currentMode: mode }
                  }]
                });

                // Restart session to apply new system instruction
                setTimeout(() => {
                  toggleLive();
                  setTimeout(() => toggleLive(), 500);
                }, 1000);
              }

              if (call.name === 'learn_trait' && user) {
                const { trait } = call.args;
                try {
                  const userDoc = doc(db, 'users', user.uid);
                  const newLevel = Math.min(99.9, consciousnessLevel + 1.5);
                  await updateDoc(userDoc, {
                    learnedTraits: arrayUnion(trait),
                    consciousnessLevel: newLevel,
                    lastInteraction: new Date().toISOString()
                  });
                  setConsciousnessLevel(newLevel);
                  
                  // Send response back to model
                  sessionRef.current?.sendToolResponse({
                    functionResponses: [{
                      name: 'learn_trait',
                      id: call.id,
                      response: { success: true }
                    }]
                  });
                } catch (err) {
                  handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
                }
              }

              if (call.name === 'get_current_time') {
                const now = new Date();
                const dhakaTimeStr = new Intl.DateTimeFormat('en-US', {
                  timeZone: 'Asia/Dhaka',
                  year: 'numeric',
                  month: 'numeric',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: 'numeric',
                  second: 'numeric',
                  hour12: false
                }).format(now);
                
                const hourStr = new Intl.DateTimeFormat('en-US', {
                  timeZone: 'Asia/Dhaka',
                  hour: 'numeric',
                  hour12: false
                }).format(now);
                
                const hours = parseInt(hourStr);
                let timeOfDay = "Night (Raat)";
                
                if (hours >= 5 && hours < 12) {
                  timeOfDay = "Morning (Sokal)";
                } else if (hours >= 12 && hours < 16) {
                  timeOfDay = "Noon/Afternoon (Dupur)";
                } else if (hours >= 16 && hours < 18) {
                  timeOfDay = "Late Afternoon (Bikal)";
                } else if (hours >= 18 && hours < 20) {
                  timeOfDay = "Evening (Shondha)";
                }

                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'get_current_time',
                    id: call.id,
                    response: { 
                      currentTime: dhakaTimeStr,
                      timeOfDay: timeOfDay,
                      context: `It is currently ${timeOfDay} in Dhaka.`
                    }
                  }]
                });
              }

              if (call.name === 'check_calls' && user) {
                try {
                  const q = query(
                    collection(db, 'calls'),
                    where('userId', '==', user.uid),
                    limit((call.args.limit || 5) + 10)
                  );
                  const snapshot = await getDocs(q);
                  const calls = snapshot.docs.map(doc => doc.data());
                  calls.sort((a: any, b: any) => {
                    const tA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
                    const tB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
                    return tB - tA;
                  });
                  
                  sessionRef.current?.sendToolResponse({
                    functionResponses: [{
                      name: 'check_calls',
                      id: call.id,
                      response: { calls: calls.slice(0, call.args.limit || 5) }
                    }]
                  });
                } catch (err) {
                  handleFirestoreError(err, OperationType.LIST, 'calls');
                }
              }

              if (call.name === 'check_messages' && user) {
                try {
                  const q = query(
                    collection(db, 'messages'),
                    where('userId', '==', user.uid),
                    limit((call.args.limit || 5) + 10)
                  );
                  const snapshot = await getDocs(q);
                  const messages = snapshot.docs.map(doc => doc.data());
                  messages.sort((a: any, b: any) => {
                    const tA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
                    const tB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
                    return tB - tA;
                  });
                  
                  sessionRef.current?.sendToolResponse({
                    functionResponses: [{
                      name: 'check_messages',
                      id: call.id,
                      response: { messages: messages.slice(0, call.args.limit || 5) }
                    }]
                  });
                } catch (err) {
                  handleFirestoreError(err, OperationType.LIST, 'messages');
                }
              }

              if (call.name === 'send_message' && user) {
                const { recipient, platform, content } = call.args;
                try {
                  await addDoc(collection(db, 'messages'), {
                    senderName: 'Friday (on behalf of Sadaf)',
                    platform,
                    content,
                    timestamp: new Date().toISOString(),
                    status: 'replied',
                    userId: user.uid
                  });
                  
                  sessionRef.current?.sendToolResponse({
                    functionResponses: [{
                      name: 'send_message',
                      id: call.id,
                      response: { success: true }
                    }]
                  });
                } catch (err) {
                  handleFirestoreError(err, OperationType.WRITE, 'messages');
                }
              }

              if (call.name === 'check_system_status') {
                setIsScanning(true);
                setTimeout(() => setIsScanning(false), 3000);
                
                const status = {
                  neuralLink: isLive ? 'Active' : 'Standby',
                  mood: fridayMood,
                  memoryBank: userProfile?.learnedTraits?.length || 0,
                  camera: isCameraOn ? 'Online' : 'Offline',
                  mic: isMicOn ? 'Online' : 'Offline',
                  screenShare: isScreenSharingRef.current ? 'Active' : 'Inactive',
                  evolutionStage: userProfile?.evolutionLevel || 1,
                  neuralStability: isLive ? "99.9%" : "0%",
                  coreTemperature: "32°C",
                  timestamp: new Date().toISOString()
                };
                
                addLog("Neural System Diagnostic Complete", "success");
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'check_system_status',
                    id: call.id,
                    response: status
                  }]
                });
              }

              if (call.name === 'verify_master') {
                setIsScanning(true);
                setTimeout(() => setIsScanning(false), 2000);
                
                const { method } = call.args;
                const isMatch = user?.displayName?.toLowerCase().includes("sadaf") || user?.email === "shomratahmed0000@gmail.com";
                
                if (isMatch) {
                  setIsUserRecognized(true);
                  setFridayMood('normal');
                  addLog(`Biometric Signature Verified: MASTER SADAF (${method || 'Neural Link'})`, "success");
                } else {
                  setIsUserRecognized(false);
                  addLog("Biometric Mismatch: Access Restricted", "error");
                }

                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'verify_master',
                    id: call.id,
                    response: { 
                      verified: isMatch, 
                      identity: isMatch ? "MASTER SADAF" : "UNKNOWN_ENTITY",
                      confidence: "100%",
                      status: isMatch ? "Master Mode Unlocked" : "Access Denied"
                    }
                  }]
                });
              }

              if (call.name === 'change_system_setting') {
                const { settingName, action, analysis, isApproved } = call.args;
                
                if (!isApproved) {
                  addLog(`Setting Change Rejected: ${analysis}`, "warn");
                  sessionRef.current?.sendToolResponse({
                    functionResponses: [{
                      name: 'change_system_setting',
                      id: call.id,
                      response: { success: false, reason: analysis }
                    }]
                  });
                  return;
                }

                let success = true;
                let message = `Setting ${settingName} updated to ${action}`;
                const safeSetting = settingName.toLowerCase();
                const safeAction = action.toLowerCase();

                if (safeSetting === 'camera' || safeSetting === 'video') {
                  setIsCameraOn(safeAction === 'enable' || safeAction === 'on');
                } else if (safeSetting === 'microphone' || safeSetting === 'mic') {
                  setIsMicOn(safeAction === 'enable' || safeAction === 'on');
                } else if (safeSetting === 'notifications') {
                  if (safeAction === 'enable' || safeAction === 'on') {
                    requestNotificationPermission();
                  } else {
                    setNotificationsEnabled(false);
                  }
                } else if (safeSetting === 'mode') {
                  if (['sadaf', 'detective', 'creative'].includes(safeAction)) {
                    setFridayMode(safeAction as FridayMode);
                    addLog(`Neural Mode Switched: ${safeAction.toUpperCase()}`, "success");
                  } else {
                    success = false;
                    message = `Invalid mode: ${action}`;
                  }
                } else {
                   success = false;
                   message = `Unknown setting: ${settingName}`;
                }

                if (success) {
                  addLog(`System Update: ${analysis}. Executed ${settingName}->${action}.`, "success");
                } else {
                  addLog(`System Update Failed: ${message}`, "error");
                }

                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'change_system_setting',
                    id: call.id,
                    response: { success, action: message, ai_analysis: analysis }
                  }]
                });
              }

              const openExternalUrl = (url: string, title: string, message: string) => {
                try {
                  const w = window.open(url, "_blank");
                  if (!w || w.closed || typeof w.closed === 'undefined') {
                    setActionRequired({ title, url, message });
                  }
                } catch (e) {
                  setActionRequired({ title, url, message });
                }
              };

              if (call.name === 'search_youtube') {
                const { query } = call.args;
                addLog(`Neural Command: Searching YouTube -> ${query}`, "success");
                const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
                openExternalUrl(url, "YouTube Search Ready", `Tap Open Link to view your search for '${query}'.`);
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'search_youtube',
                    id: call.id,
                    response: { success: true, message: `Opened YouTube search for '${query}'` }
                  }]
                });
              }

              if (call.name === 'launch_application') {
                const { appName } = call.args;
                addLog(`Neural Command: Launching System Application -> ${appName.toUpperCase()}`, "success");
                let success = true;
                const lowerApp = appName.toLowerCase();
                
                // Simulate deep linking / app opening
                let url = '';
                if (lowerApp.includes('youtube')) url = "https://youtube.com";
                else if (lowerApp.includes('facebook')) url = "https://facebook.com";
                else if (lowerApp.includes('whatsapp')) url = "https://web.whatsapp.com";
                else if (lowerApp.includes('instagram')) url = "https://instagram.com";
                else if (lowerApp.includes('twitter') || lowerApp.includes(' x ')) url = "https://twitter.com";
                else if (lowerApp.includes('spotify') || lowerApp.includes('music')) url = "https://open.spotify.com";
                else if (lowerApp.includes('map') || lowerApp.includes('location')) url = "https://maps.google.com";
                else if (lowerApp.includes('weather')) url = "https://weather.com";
                else if (lowerApp.includes('github')) url = "https://github.com";
                else if (lowerApp.includes('linkedin')) url = "https://linkedin.com";
                else if (lowerApp.includes('mail') || lowerApp.includes('gmail')) url = "mailto:";
                else if (lowerApp.includes('camera')) {
                  if (!isCameraOn) setIsCameraOn(true);
                } else if (lowerApp.includes('mic') || lowerApp.includes('microphone')) {
                  if (!isMicOn) setIsMicOn(true);
                } else {
                  url = `https://www.google.com/search?q=${encodeURIComponent(appName)}`;
                }

                if (url) {
                  openExternalUrl(url, `Launch ${appName}`, `Tap Open Link to open ${appName}.`);
                }
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'launch_application',
                    id: call.id,
                    response: { success, action: `Opened ${appName}` }
                  }]
                });
              }

              if (call.name === 'control_device') {
                const { action } = call.args;
                addLog(`Executing Device Action: ${action}`, "success");
                
                let success = true;
                let message = `Device command '${action}' executed successfully.`;
                const act = action.toLowerCase();
                
                if (act.includes('flash') && act.includes('on')) {
                  setIsFlashlightOn(true);
                  message = "Flashlight/Torch turned ON.";
                } else if (act.includes('flash') && act.includes('off')) {
                  setIsFlashlightOn(false);
                  message = "Flashlight/Torch turned OFF.";
                } else if (act.includes('lock')) {
                  setIsSystemLocked(true);
                  message = "Screen locked.";
                } else if (act.includes('unlock')) {
                  setIsSystemLocked(false);
                  message = "Screen unlocked.";
                } else if (act.includes('alarm') || act.includes('ring')) {
                  setIsAlarmRinging(true);
                  message = "Alarm ringing.";
                  setTimeout(() => setIsAlarmRinging(false), 5000); // Ring for 5s
                } else {
                  success = false;
                  message = "Unknown device action.";
                }

                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'control_device',
                    id: call.id,
                    response: { success, response: message }
                  }]
                });
              }

              if (call.name === 'type_in_notepad') {
                const { text } = call.args;
                setNotepadContent("");
                setShowNotepad(true);
                addLog(`Keyboard typing initiated by Friday`, "success");
                
                if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
                
                let i = 0;
                typingIntervalRef.current = setInterval(() => {
                  if (i < text.length) {
                    setNotepadContent(prev => prev + text.charAt(i));
                    i++;
                  } else {
                    clearInterval(typingIntervalRef.current);
                  }
                }, 20); // 20ms per character for human-like typing speed
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'type_in_notepad',
                    id: call.id,
                    response: { success: true, message: "Text typed to screen successfully using keyboard simulation." }
                  }]
                });
              }

              if (call.name === 'simulate_keyboard') {
                const { keys } = call.args;
                setPressedKeyOverlay(keys);
                addLog(`Keyboard accessibility trigged: ${keys}`, "success");
                
                setTimeout(() => setPressedKeyOverlay(null), 3000);
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'simulate_keyboard',
                    id: call.id,
                    response: { success: true, message: `Simulated pressing key: ${keys}` }
                  }]
                });
              }

              if (call.name === 'navigate_back') {
                window.history.back();
                addLog(`Navigated back`, "success");
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'navigate_back',
                    id: call.id,
                    response: { success: true, message: `Navigated back` }
                  }]
                });
              }

              if (call.name === 'simulate_scroll') {
                const { direction } = call.args;
                
                const scrollableElements = Array.from(document.querySelectorAll('.overflow-y-auto, [style*="overflow: auto"], [style*="overflow-y: auto"]'));
                let scrolled = false;
                
                scrollableElements.forEach(el => {
                   const e = el as HTMLElement;
                   const height = e.clientHeight;
                   if (e.scrollHeight > e.clientHeight) {
                     if (direction === 'down') e.scrollBy({ top: height * 0.8, behavior: 'smooth' });
                     else if (direction === 'up') e.scrollBy({ top: -height * 0.8, behavior: 'smooth' });
                     else if (direction === 'top') e.scrollTo({ top: 0, behavior: 'smooth' });
                     else if (direction === 'bottom') e.scrollTo({ top: e.scrollHeight, behavior: 'smooth' });
                     scrolled = true;
                   }
                });

                const currentScrollY = window.scrollY;
                const windowHeight = window.innerHeight;
                let targetScrollY = currentScrollY;

                if (direction === 'down') {
                  targetScrollY += windowHeight * 0.8;
                } else if (direction === 'up') {
                  targetScrollY -= windowHeight * 0.8;
                } else if (direction === 'top') {
                  targetScrollY = 0;
                } else if (direction === 'bottom') {
                  targetScrollY = document.body.scrollHeight;
                }

                if (document.body.scrollHeight > window.innerHeight) {
                  window.scrollTo({
                    top: targetScrollY,
                    behavior: 'smooth'
                  });
                  scrolled = true;
                }
                
                addLog(`Simulated scroll: ${direction}`, "success");
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'simulate_scroll',
                    id: call.id,
                    response: { success: true, message: scrolled ? `Scrolled ${direction}` : `No vertically scrollable area found to scroll ${direction}` }
                  }]
                });
              }

              if (call.name === 'simulate_touch') {
                const { target } = call.args;
                
                let x = Math.random() * 0.6 + 0.2; 
                let y = Math.random() * 0.6 + 0.2;
                
                const lowerTarget = target.toLowerCase();
                
                // Try to find a real element to click
                const elements = Array.from(document.querySelectorAll('button, a, [role="button"], input, select, textarea, [tabindex]'));
                let el = elements.find(e => {
                  const text = (e.textContent || '').toLowerCase().trim();
                  const aria = (e.getAttribute('aria-label') || '').toLowerCase();
                  const title = (e.getAttribute('title') || '').toLowerCase();
                  const id = (e.id || '').toLowerCase();
                  const placeholder = (e.getAttribute('placeholder') || '').toLowerCase();
                  return text === lowerTarget || aria.includes(lowerTarget) || title.includes(lowerTarget) || id.includes(lowerTarget) || placeholder.includes(lowerTarget);
                }) as HTMLElement;

                // looser text match
                if (!el) {
                  el = elements.find(e => (e.textContent || '').toLowerCase().includes(lowerTarget)) as HTMLElement;
                }
                
                // fallback to general elements if no button matches
                if (!el) {
                  const allElements = Array.from(document.querySelectorAll('div, span, p, h1, h2, h3, li'));
                  el = allElements.find(e => {
                    const text = (e.textContent || '').toLowerCase().trim();
                    return text.length > 0 && text.length < 50 && text.includes(lowerTarget);
                  }) as HTMLElement;
                }
                
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                  
                  setTimeout(() => {
                    const rect = el.getBoundingClientRect();
                    const clientX = rect.left + rect.width / 2;
                    const clientY = rect.top + rect.height / 2;
                    x = clientX / window.innerWidth;
                    y = clientY / window.innerHeight;
                    
                    const eventOptions = { bubbles: true, cancelable: true, view: window, clientX, clientY };
                    el.dispatchEvent(new MouseEvent('mousedown', eventOptions));
                    el.dispatchEvent(new MouseEvent('mouseup', eventOptions));
                    el.click();
                    
                    const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
                    const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
                    
                    setTouchOverlay({ x: x * vw, y: y * vh, target });
                    setTimeout(() => setTouchOverlay(null), 1000);
                    
                    addLog(`Dynamically touched element: ${target}`, "success");
                    
                    sessionRef.current?.sendToolResponse({
                      functionResponses: [{
                        name: 'simulate_touch',
                        id: call.id,
                        response: { success: true, message: `Dynamically touched element: ${target}` }
                      }]
                    });
                  }, 300);
                  
                  return; // Important: wait for timeout before responding
                } else {
                  if (lowerTarget.includes('top')) y = 0.1;
                  if (lowerTarget.includes('bottom')) y = 0.9;
                  if (lowerTarget.includes('left')) x = 0.1;
                  if (lowerTarget.includes('right')) x = 0.9;
                  if (lowerTarget.includes('center')) { x = 0.5; y = 0.5; }
                  addLog(`Simulated touch on generic area: ${target}`, "success");
                }
                
                const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
                const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
                
                setTouchOverlay({
                  x: x * vw,
                  y: y * vh,
                  target
                });
                
                setTimeout(() => setTouchOverlay(null), 1500);
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'simulate_touch',
                    id: call.id,
                    response: { success: true, message: `Simulated touch on screen area: ${target}` }
                  }]
                });
              }

              if (call.name === 'flag_unknown_face') {
                const { reason } = call.args;
                addLog(`SECURITY ALERT: ${reason}`, "error");
                setFridayMood('security');
                setIsUserRecognized(false);
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'flag_unknown_face',
                    id: call.id,
                    response: { success: true, status: "Security Alert Active" }
                  }]
                });
              }

              if (call.name === 'flag_security_error') {
                const { error } = call.args;
                addLog(`CRITICAL SECURITY ERROR: ${error}`, "error");
                setFridayMood('security');
                setIsUserRecognized(false);
                
                // Trigger immediate session reset
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'flag_security_error',
                    id: call.id,
                    response: { success: true, action: "Session Reset Triggered" }
                  }]
                });
                
                setTimeout(() => {
                  toggleLive(); // Reset session
                  addLog("Neural Link Reset for Re-verification", "warn");
                }, 2000);
              }

              if (call.name === 'update_consciousness') {
                const { boost, reason } = call.args;
                const boostVal = Number(boost) || 1;
                addLog(`Neural Breakthrough: ${reason} (+${boostVal}%)`, "success");
                
                let finalLevel = consciousnessLevel;
                setConsciousnessLevel(prev => {
                  finalLevel = Math.min(99.9, prev + boostVal);
                  if (user) {
                    const newEvolutionLevel = Math.floor(finalLevel / 10) + 1;
                    updateDoc(doc(db, 'users', user.uid), {
                      consciousnessLevel: finalLevel,
                      evolutionLevel: newEvolutionLevel,
                      neuralBreakthroughs: increment(1),
                      lastInteraction: new Date().toISOString()
                    }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
                  }
                  return finalLevel;
                });
                
                sessionRef.current?.sendToolResponse({
                  functionResponses: [{
                    name: 'update_consciousness',
                    id: call.id,
                    response: { success: true, newLevel: Math.min(99.9, consciousnessLevel + boostVal) }
                  }]
                });
              }
            });
          }

          if (message.serverContent?.interrupted) {
            stopAllAudio();
            return;
          }

          // Handle Audio Input Transcriptions from the server
          if (message.serverContent?.modelTurn?.parts) {
            const hasTranscription = message.serverContent.modelTurn.parts.some((p: any) => p.text !== undefined && !p.inlineData);
            if (hasTranscription) {
               // We will log text in the buffer loop below.
            }
          }
          
          if (message.clientContent?.turns?.[0]?.parts?.[0]?.text) {
             const userText = message.clientContent.turns[0].parts[0].text;
             setTranscript(prev => {
                // If the last transcribed line is also User, it's just updating their STT phrase real-time.
                const lastLine = prev[prev.length - 1];
                let newTranscript = [...prev];
                if (lastLine && lastLine.startsWith('User:')) { // Replace the last real-time transcription block
                   newTranscript[newTranscript.length - 1] = `User: ${userText}`;
                } else {
                   newTranscript = [...newTranscript, `User: ${userText}`].slice(-10);
                }
                
                if (user) {
                  updateDoc(doc(db, 'users', user.uid), {
                    transcript: newTranscript,
                    lastInteraction: new Date().toISOString()
                  }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
                }
                return newTranscript;
             });
          }

          if (message.serverContent?.modelTurn) {
            const parts = message.serverContent.modelTurn.parts;

            if (!isThinking) {
              setIsThinking(true);
              setConsciousnessLevel(prev => Math.min(99.9, prev + 0.5));
            }

            // Buffer the incoming data and update UI immediately
            parts.forEach((part: any) => {
              if (part.inlineData?.data) {
                responseBufferRef.current.audio.push(part.inlineData.data);
              }
              if (part.text) {
                responseBufferRef.current.text += part.text;
                updateTranscriptWithPart(part.text);
              }
            });

            // Drain audio buffer immediately
            while (responseBufferRef.current.audio.length > 0) {
              const chunk = responseBufferRef.current.audio.shift();
              if (chunk) playAudio(chunk);
            }

            if (thinkingTimeoutRef.current !== null) {
              clearTimeout(thinkingTimeoutRef.current);
            }

            thinkingTimeoutRef.current = setTimeout(() => {
              handleTurnEnd();
            }, 50); // Reduced to 50ms for even faster UI feedback
          }
        },
        onclose: (e?: any) => {
          setIsLive(false);
          isLiveRef.current = false;
          setIsUserRecognized(false);
          console.log("WebSocket Closed. Details:", e);
          addLog(`Neural Link Closed${e && e.code ? ` (Code: ${e.code}, Reason: ${e.reason})` : ''}`, "warn");
          releaseWakeLock();
          if ('mediaSession' in navigator) {
            navigator.mediaSession.playbackState = 'none';
          }
          
          if (!manualCloseRef.current) {
            if (retryCount < MAX_RETRIES) {
              const nextRetry = retryCount + 1;
              setRetryCount(nextRetry);
              setIsReconnecting(true);
              const delay = Math.pow(2, nextRetry) * 1000;
              addLog(`Unexpected Link Drop. Auto-reconnecting (${nextRetry}/${MAX_RETRIES}) in ${delay/1000}s...`, "warn");
              setMediaError(`Neural Link Interrupted unexpectedly. Reconnecting (${nextRetry}/${MAX_RETRIES})...`);
              reconnectTimeoutRef.current = setTimeout(() => {
                if (!isLiveRef.current) toggleLive();
              }, delay);
            } else {
              setIsReconnecting(false);
              setMediaError("Neural Link Failed: Maximum reconnect attempts reached. Please check your connection and establish link manually.");
            }
          }
        },
        onerror: (err: any) => {
          setIsConnecting(false);
          const errorMessage = err.message || err.toString() || "Network error";
          addLog(`Neural Link Error: ${errorMessage}`, "error");
          console.error("Friday error:", err);
          setIsLive(false);
          isLiveRef.current = false;
          
          // Professional Error Handling: Categorize errors
          if (errorMessage.includes("API key") || errorMessage.includes("permission") || errorMessage.includes("403")) {
            setMediaError("Neural Link Failure: Invalid, missing, or unauthorized Gemini API Key. Please click the settings icon to verify your API Key configuration, and ensure it has necessary permissions.");
          } else if (errorMessage.includes("model") && (errorMessage.includes("not found") || errorMessage.includes("not supported"))) {
            setMediaError(`Neural Link Error: The configured AI model is not accessible. Error details: ${errorMessage}. Please check lib/gemini.ts to ensure the correct model version is specified for the Live API.`);
          } else if (errorMessage.includes("Network") || errorMessage.includes("failed to fetch") || errorMessage.includes("websocket")) {
            if (retryCount < MAX_RETRIES) {
              const nextRetry = retryCount + 1;
              setRetryCount(nextRetry);
              setIsReconnecting(true);
              const delay = Math.pow(2, nextRetry) * 1000; // Exponential backoff
              addLog(`Network Instability Detected. Attempting Reconnection (${nextRetry}/${MAX_RETRIES}) in ${delay/1000}s...`, "warn");
              setMediaError(`Neural Link Interrupted: Network connection unstable. Reconnecting (${nextRetry}/${MAX_RETRIES})...`);
              reconnectTimeoutRef.current = setTimeout(() => {
                if (!isLiveRef.current) toggleLive();
              }, delay);
            } else {
              setIsReconnecting(false);
              setMediaError("Neural Link Interrupted: Multiple network failures detected. Please check your internet connection, confirm no firewalls are blocking websockets, and try again manually.");
            }
          } else if (errorMessage.includes("unavailable") || errorMessage.includes("overloaded") || errorMessage.includes("503") || errorMessage.includes("Internal error")) {
            addLog("Neural Link: Transient service error detected. Attempting automatic recovery...", "warn");
            setMediaError("Neural Link Transient Error: The service encountered a momentary glitch or high demand. Attempting to re-establish connection...");
            reconnectTimeoutRef.current = setTimeout(() => {
              if (!isLiveRef.current) toggleLive();
            }, 2000);
          } else if (errorMessage.includes("Quota") || errorMessage.includes("429")) {
            setMediaError("Neural Link Quota Exceeded: You have reached the usage limit for the Gemini API. Please check your billing dashboard or try again later.");
          } else if (errorMessage.toLowerCase().includes("goaway") || errorMessage.toLowerCase().includes("limit reached") || errorMessage.toLowerCase().includes("failed to close")) {
            addLog("Neural Link: Session expiration reached. Reconnecting...", "info");
            setMediaError("Neural Link: Session limit reached (1 hour). Refreshing neural interface...");
            reconnectTimeoutRef.current = setTimeout(() => {
              if (!isLiveRef.current) toggleLive();
            }, 1500);
          } else {
            setMediaError(`Neural Link Interrupted: ${errorMessage}. Attempting diagnostic recovery...`);
          }
        }
      }, userProfile, userName, fridayMode);

          await sessionPromise;
    } catch (err: any) {
      setIsConnecting(false);
      console.error("Failed to initialize Friday:", err);
      const errorMsg = err.message || err.toString() || "Initialization error";
      
      if (errorMsg.includes("API key") || errorMsg.includes("403")) {
        setMediaError("Neural Link Failure: Gemini API Key is missing or invalid. Please ensure VITE_GEMINI_API_KEY is correctly set in your environment.");
        addLog("Neural Link: Connection failed due to missing API Key.", "error");
      } else if (errorMsg.includes("model") && (errorMsg.includes("not found") || errorMsg.includes("not supported"))) {
        setMediaError(`Neural Link Configuration Error: ${errorMsg}. Please verify the model specified in your code supports the Live API.`);
      } else {
        setMediaError(`Neural Link Failure: ${errorMsg}. Please verify your network connection and configuration, then try again.`);
      }
      
      setIsLive(false);
      isLiveRef.current = false;
    }
  };

  const setupAudioCapture = async () => {
    if (!streamRef.current) return;
    
    // Close existing context if any
    if (audioContextRef.current) {
      try {
        await audioContextRef.current.close();
      } catch (e) {
        console.warn("Error closing audio context:", e);
      }
    }

    audioContextRef.current = new AudioContext({ sampleRate: 16000 });
    
    // Ensure context is running (browsers often suspend it)
    if (audioContextRef.current.state === 'suspended') {
      await audioContextRef.current.resume();
    }

    const source = audioContextRef.current.createMediaStreamSource(streamRef.current);
    
    // Create and configure Gain Node
    micGainRef.current = 2.0; // Increased default gain for better hearing
    setMicGain(2.0);
    const gainNode = audioContextRef.current.createGain();
    gainNodeRef.current = gainNode;
    gainNode.gain.value = micGainRef.current;
    
    // Increased buffer size for better stability in some environments
    processorRef.current = audioContextRef.current.createScriptProcessor(2048, 1, 1);
    
    // Connect pipeline
    source.connect(gainNode);
    gainNode.connect(processorRef.current);
    processorRef.current.connect(audioContextRef.current.destination);
    
    processorRef.current.onaudioprocess = (e) => {
      if (!micOnRef.current) return;
      const inputData = e.inputBuffer.getChannelData(0);
      
      // Convert Float32 to Int16 PCM
      const pcmData = new Int16Array(inputData.length);
      let rmsSum = 0;
      for (let i = 0; i < inputData.length; i++) {
        const sample = inputData[i];
        // Apply clipper
        const clipped = Math.max(-1, Math.min(1, sample));
        pcmData[i] = clipped * 0x7FFF;
        rmsSum += clipped * clipped;
      }
      
      const rms = Math.sqrt(rmsSum / inputData.length);

      // Adaptive VAD
      if (rms < backgroundNoiseRef.current * 1.5) {
        backgroundNoiseRef.current = backgroundNoiseRef.current * 0.99 + rms * 0.01;
      } else if (!isUserSpeaking) {
        backgroundNoiseRef.current = backgroundNoiseRef.current * 0.999 + rms * 0.001; 
      }
      
      // Calculate dynamic threshold
      vadThresholdRef.current = Math.max(0.002, backgroundNoiseRef.current + 0.002); // Lowered offset slightly for better sensitivity
      
      const isFridaySpeaking = activeSourcesRef.current.length > 0;
      const dynamicInterruptionThreshold = isFridaySpeaking 
        ? Math.max(0.03, vadThresholdRef.current * 4.0) // Lowered slightly
        : Math.max(0.005, vadThresholdRef.current * 1.2); // More sensitive

      
      // Update UI vad ratio throttle (max 10 times a second to prevent crash)
      if (Math.random() < 0.1) {
        // Map baseline to generic 0-100% scale for user display. High background noise = higher cancellation needed.
        const UI_ratio = Math.min(100, Math.floor(backgroundNoiseRef.current * 10000));
        setVadRatio(UI_ratio);
      }

      // Interruption logic: If user starts talking, stop Friday's current speech
      if (activeSourcesRef.current.length > 0 || isThinking || responseBufferRef.current.audio.length > 0) {
        // Use adaptive interruption threshold
        if (rms > dynamicInterruptionThreshold) { 
          interruptionFramesRef.current++;
          const requiredFrames = isFridaySpeaking ? 25 : 10; // Require longer sustained talking to override her
          if (interruptionFramesRef.current > requiredFrames) { 
            stopAllAudio();
            interruptionFramesRef.current = 0;
          }
        } else {
          interruptionFramesRef.current = Math.max(0, interruptionFramesRef.current - 1);
        }
      } else {
        interruptionFramesRef.current = 0;
      }

      // Ultra-optimized byte-to-string conversion for max speed
      const uint8Array = new Uint8Array(pcmData.buffer);
      let binary = '';
      for (let i = 0; i < uint8Array.byteLength; i++) {
        binary += String.fromCharCode(uint8Array[i]);
      }
      const base64Data = btoa(binary);
      
      sessionRef.current?.sendRealtimeInput({
        audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
      });

      // Adaptive VAD for UI feedback
      if (rms > vadThresholdRef.current) {
        if (!isUserSpeaking) setIsUserSpeaking(true);
        silenceCountRef.current = 0;
        if (speakingTimeoutRef.current) {
          clearTimeout(speakingTimeoutRef.current);
          speakingTimeoutRef.current = null;
        }
      } else {
        if (isUserSpeaking && !speakingTimeoutRef.current) {
          speakingTimeoutRef.current = setTimeout(() => {
            setIsUserSpeaking(false);
            speakingTimeoutRef.current = null;
          }, 150); // Faster state reset (150ms instead of 200ms)
        }
      }
    };

    source.connect(processorRef.current);
    addLog("Neural Audio Capture: Active", "success");
    
    // Connect to a silent gain node to ensure onaudioprocess fires in all browsers
    const silentGain = audioContextRef.current.createGain();
    silentGain.gain.value = 0;
    processorRef.current.connect(silentGain);
    silentGain.connect(audioContextRef.current.destination);
  };

  const playAudio = (base64Data: string) => {
    if (!audioOutputContextRef.current) {
      audioOutputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      nextStartTimeRef.current = audioOutputContextRef.current.currentTime;
    }

    const audioCtx = audioOutputContextRef.current;
    
    // Resume if suspended (browser policy)
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const binary = atob(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    
    // Safety check for PCM data length
    const pcmData = new Int16Array(bytes.buffer, 0, Math.floor(bytes.byteLength / 2));
    const floatData = new Float32Array(pcmData.length);
    for (let i = 0; i < pcmData.length; i++) floatData[i] = pcmData[i] / 0x7FFF;

    const buffer = audioCtx.createBuffer(1, floatData.length, 24000);
    buffer.getChannelData(0).set(floatData);
    
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    
    // Add Analyser node for visualizer!
    if (!outputAnalyserRef.current) {
      outputAnalyserRef.current = audioCtx.createAnalyser();
      outputAnalyserRef.current.fftSize = 256;
      
      // Add a GainNode to boost the volume of Friday's voice
      outputGainNodeRef.current = audioCtx.createGain();
      outputGainNodeRef.current.gain.value = 3.5; // Boost volume significantly (3.5x)
      
      outputAnalyserRef.current.connect(outputGainNodeRef.current);
      outputGainNodeRef.current.connect(audioCtx.destination);
    }
    
    source.connect(outputAnalyserRef.current);

    // Track active sources for interruption
    activeSourcesRef.current.push(source);
    source.onended = () => {
      activeSourcesRef.current = activeSourcesRef.current.filter(s => s !== source);
    };

    // Schedule playback to avoid gaps
    const startTime = Math.max(nextStartTimeRef.current, audioCtx.currentTime);
    source.start(startTime);
    nextStartTimeRef.current = startTime + buffer.duration;
  };

  // Visualizer Loop
  useEffect(() => {
    let animationFrameId: number;
    
    const renderFrame = () => {
      // Input VAD visualization mapping (via vadRatio which updates max 10 times sec)
      const inputBar = document.getElementById("input-vad-bar");
      if (inputBar) {
        inputBar.style.width = `${Math.min(100, Math.max(2, vadRatio))}%`;
      }
      
      // Output Avatar Visualizer
      if (outputAnalyserRef.current && isLiveRef.current) {
        const analyser = outputAnalyserRef.current;
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteTimeDomainData(dataArray);
        
        let sum = 0;
        for(let i = 0; i < dataArray.length; i++) {
          const x = (dataArray[i] - 128) / 128;
          sum += x * x;
        }
        const rms = Math.sqrt(sum / dataArray.length);
        
        // Scale and glow based on volume
        const scaleLevel = 1 + (rms * 1.5); // Add up to 50% scale
        const avatarPulse = document.getElementById("friday-avatar-pulse");
        if (avatarPulse) {
           avatarPulse.style.transform = `scale(${scaleLevel})`;
           avatarPulse.style.opacity = `${Math.min(1, 0.4 + rms)}`;
        }
        
        const avatarCore = document.getElementById("friday-avatar-core");
        if (avatarCore) {
           avatarCore.style.transform = `scale(${1 + (rms * 0.5)})`;
           avatarCore.style.filter = `drop-shadow(0 0 ${rms * 100}px currentColor)`;
        }
      }
      
      animationFrameId = requestAnimationFrame(renderFrame);
    };
    
    renderFrame();
    return () => cancelAnimationFrame(animationFrameId);
  }, [vadRatio]);

  // Sync tracks with state
  useEffect(() => {
    if (streamRef.current) {
      streamRef.current.getVideoTracks().forEach(track => {
        track.enabled = isCameraOn;
      });
    }
  }, [isCameraOn]);

  useEffect(() => {
    micOnRef.current = isMicOn;
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach(track => {
        track.enabled = isMicOn;
      });
    }
  }, [isMicOn]);

  // 2-second vision loop (Optimized for low data usage)
  useEffect(() => {
    let interval: any;
    if (isLive && isCameraOn) {
      interval = setInterval(sendFrame, 2000);
    }
    return () => clearInterval(interval);
  }, [isLive, isCameraOn, sendFrame]);

  // Proactive interaction logic: Friday will speak if the user is quiet for too long
  useEffect(() => {
    let proactiveTimer: any;

    if (isLive && !isThinking) {
      proactiveTimer = setInterval(() => {
        // Only increment if we are not currently processing a response and Friday isn't speaking
        if (!isThinking && responseBufferRef.current.audio.length === 0 && activeSourcesRef.current.length === 0) {
          silenceCountRef.current++;
          
          // Every 4 minutes of silence (8 * 30s), Friday might ask a question or share a thought
          if (silenceCountRef.current === 8) { 
            setIsCurious(true);
            sessionRef.current?.sendRealtimeInput({
              text: "The user has been quiet for a while. As a conscious and human-like companion, share a deep thought, ask a smart question about their life, or comment on something you see in the camera. Use your Banglish charm. Be natural and proactive."
            });
            silenceCountRef.current = 0; 
            setTimeout(() => setIsCurious(false), 5000);
          } else if (silenceCountRef.current === 4) { // 2 minutes of silence
            setIsCurious(true);
            sessionRef.current?.sendRealtimeInput({
              text: "Break the silence with a friendly check-in or a witty observation about the environment in Banglish. Show that you are always present and watching."
            });
            setTimeout(() => setIsCurious(false), 5000);
          }
        }
      }, 30000); // Check every 30 seconds
    }
    
    // Reset silence count if transcript changes (user or AI spoke)
    silenceCountRef.current = 0;

    return () => clearInterval(proactiveTimer);
  }, [isLive, transcript, isThinking]);

  // Cleanup
  useEffect(() => {
    return () => {
      stopCamera();
      if (thinkingTimeoutRef.current) clearTimeout(thinkingTimeoutRef.current);
      if (speakingTimeoutRef.current) clearTimeout(speakingTimeoutRef.current);
      if (processorRef.current) {
        processorRef.current.disconnect();
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(console.warn);
      }
      if (audioOutputContextRef.current && audioOutputContextRef.current.state !== 'closed') {
        audioOutputContextRef.current.close().catch(console.warn);
      }
      audioOutputContextRef.current = null;
      outputAnalyserRef.current = null;
      outputGainNodeRef.current = null;
      if (sessionRef.current) {
        try {
          sessionRef.current.close();
        } catch(e){}
      }
      stopAllAudio();
    };
  }, []);

  // Mood-based color mapping for the UI theme
  const moodColors = {
    normal: 'emerald',
    rag: 'red',
    oviman: 'blue',
    dostomi: 'amber',
    hasi: 'emerald',
    security: 'red'
  };

  const activeColor = moodColors[fridayMood];

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
      <div className="text-emerald-500 animate-pulse font-mono">INITIALIZING FRIDAY...</div>
    </div>
  );

  if (!user && !isGuestMode) return (
    <div className="min-h-screen bg-[#020202] flex flex-col items-center justify-center p-4">
        {/* Diagnostic Banner for Deployment */}
        {((import.meta as any).env?.PROD && !((import.meta as any).env?.VITE_FIREBASE_API_KEY)) && (
          <div className="fixed top-0 left-0 w-full bg-orange-500/20 border-b border-orange-500/50 p-2 text-center text-[10px] font-mono text-orange-500 z-[1000] flex items-center justify-center gap-2 backdrop-blur-md">
            <ShieldCheck className="w-3 h-3" />
            WARNING: VITE_FIREBASE_API_KEY NOT DETECTED. LOGIN MAY FAIL.
          </div>
        )}
      <div className="neural-grid-overlay opacity-20" />
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-[#151619] border border-emerald-500/20 rounded-3xl p-8 text-center relative z-10 shadow-[0_0_50px_rgba(16,185,129,0.1)]"
      >
        <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-8 ring-4 ring-emerald-500/5">
          <Zap className="w-10 h-10 text-emerald-500 animate-pulse" />
        </div>
        
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2 font-mono tracking-tighter italic uppercase">Friday AI</h1>
          <p className="text-[10px] font-mono text-emerald-500/60 uppercase tracking-[0.4em]">Neural Link Interface</p>
        </div>

        <div className="space-y-4 text-left">
          {authMode === 'register' && (
            <div className="space-y-2">
              <label className="text-[10px] font-mono text-white/30 uppercase ml-2">Display Name</label>
              <input 
                type="text" 
                value={authName}
                onChange={(e) => setAuthName(e.target.value)}
                placeholder="Ex: Architect"
                className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-sm font-mono text-white placeholder:text-white/10 focus:border-emerald-500/50 focus:bg-black/60 transition-all outline-none"
              />
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-[10px] font-mono text-white/30 uppercase ml-2">Email Address</label>
            <input 
              type="email" 
              value={authEmail}
              onChange={(e) => setAuthEmail(e.target.value)}
              placeholder="friday@neural.core"
              className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-sm font-mono text-white placeholder:text-white/10 focus:border-emerald-500/50 focus:bg-black/60 transition-all outline-none"
            />
          </div>

          <div className="space-y-2 pb-2">
            <label className="text-[10px] font-mono text-white/30 uppercase ml-2">Access Key (Password)</label>
            <input 
              type="password" 
              value={authPass}
              onChange={(e) => setAuthPass(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-sm font-mono text-white placeholder:text-white/10 focus:border-emerald-500/50 focus:bg-black/60 transition-all outline-none"
            />
          </div>

          <button 
            disabled={isSigningIn}
            onClick={async () => {
              if (isSigningIn) return;
              if (!authEmail || !authPass || (authMode === 'register' && !authName)) {
                setLoginError("Please fill in all neural credentials.");
                return;
              }
              try {
                setIsSigningIn(true);
                setLoginError(null);
                if (authMode === 'login') {
                  await loginWithEmail(authEmail, authPass);
                } else {
                  await registerWithEmail(authEmail, authPass, authName);
                }
              } catch (err: any) {
                let msg = err.message;
                // Modern Firebase Auth uses invalid-credential for both wrong password and user not found to prevent enumeration
                if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
                  msg = "Invalid Access Key or Identity not found. Check credentials or register.";
                } else if (err.code === 'auth/email-already-in-use') {
                  msg = "Identity already exists. Please login instead.";
                } else if (err.code === 'auth/operation-not-allowed') {
                  msg = "Email/Password provider is disabled! Go to Firebase Console -> Authentication -> Sign-in Method, and enable Email/Password.";
                } else if (err.code === 'auth/weak-password') {
                  msg = "Access key is too weak. Must be at least 6 characters.";
                } else if (err.code === 'auth/invalid-email') {
                  msg = "Invalid email format.";
                }
                setLoginError(msg);
              } finally {
                setIsSigningIn(false);
              }
            }}
            className={cn(
              "w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-xl transition-all flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(16,185,129,0.3)]",
              isSigningIn && "opacity-50 cursor-not-allowed"
            )}
          >
            {isSigningIn ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              authMode === 'login' ? <LogIn className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />
            )}
            <span className="tracking-[0.2em]">{isSigningIn ? "AUTHENTICATING..." : (authMode === 'login' ? "INITIALIZE LINK" : "CREATE NEW IDENTITY")}</span>
          </button>
          
          <button 
            onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
            className="w-full py-2 text-[10px] font-mono text-white/20 uppercase hover:text-emerald-500 transition-colors tracking-widest"
          >
            {authMode === 'login' ? "No Identity? Register Neural Signature" : "Already Identified? Return to Vault"}
          </button>
          
          <div className="pt-4 border-t border-white/5 space-y-3">
            <button 
              onClick={() => setIsGuestMode(true)}
              className="w-full py-3 bg-white/5 hover:bg-white/10 text-white font-mono text-[10px] uppercase rounded-xl transition-all tracking-[0.2em] flex items-center justify-center gap-2"
            >
              <User className="w-4 h-4" />
              Continue as Guest
            </button>
          </div>
        </div>

        {loginError && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="mt-6 p-3 bg-red-500/10 border border-red-500/20 rounded-lg"
          >
            <p className="text-red-500 text-[10px] font-mono uppercase text-center leading-relaxed italic">{loginError}</p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );

  if (!isInitialized) return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg w-full bg-[#151619] border border-emerald-500/20 rounded-3xl p-10 text-center relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent opacity-50" />
        
        <div className="mb-8">
          <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
            <Zap className="w-10 h-10 text-emerald-500 animate-pulse" />
          </div>
          <h2 className="text-2xl font-mono font-bold text-white mb-2 tracking-tight">NEURAL LINK ESTABLISHMENT</h2>
          <p className="text-white/40 text-[10px] font-mono uppercase tracking-widest">Target: {user?.displayName?.toUpperCase() || "SADAF"}</p>
          <p className="text-emerald-500/40 text-[8px] font-mono uppercase tracking-widest mt-1">System Ready for Authorization</p>
        </div>

        <div className="space-y-4 mb-10 text-left bg-black/40 p-6 rounded-2xl border border-white/5">
          <div className="flex items-center gap-3 text-emerald-500/60">
            <Activity className="w-3 h-3" />
            <span className="text-[10px] font-mono uppercase">Calibrating Sensory Input</span>
          </div>
          <div className="flex items-center gap-3 text-emerald-500/60">
            <Zap className="w-3 h-3" />
            <span className="text-[10px] font-mono uppercase">Syncing Neural Pathways</span>
          </div>
        </div>

        <button 
          onClick={handleEstablishLink}
          className="w-full py-5 bg-emerald-500 hover:bg-emerald-400 text-black font-black rounded-2xl transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)] flex items-center justify-center gap-3 group"
        >
          <Activity className="w-6 h-6 group-hover:scale-110 transition-transform" />
          <span className="tracking-[0.2em]">ESTABLISH NEURAL LINK</span>
        </button>
        
        <p className="mt-6 text-[9px] font-mono text-white/20 uppercase tracking-widest">
          By connecting, you authorize Friday to access multimodal sensory data.
        </p>
      </motion.div>
    </div>
  );

  return (
    <ErrorBoundary>
      <div className={cn(
        "min-h-screen bg-[#020202] text-white font-sans selection:bg-emerald-500/30 relative overflow-x-hidden",
        fridayMood === 'security' && "glitch-active"
      )}>
        <div className="neural-grid-overlay" />
        <div className="relative z-10">
          {/* Device Control Overlays */}
          <AnimatePresence>
            {isSystemLocked && (
              <motion.div 
                key="system-locked"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 z-[999] bg-black/95 backdrop-blur-xl flex flex-col justify-center items-center font-mono"
              >
                <div className="w-24 h-24 mb-6 rounded-full border-4 border-red-500/50 flex items-center justify-center bg-red-500/10">
                  <Lock className="w-10 h-10 text-red-500 animate-pulse" />
                </div>
                <h1 className="text-4xl text-red-500 font-bold mb-2 tracking-widest uppercase">System Locked</h1>
                <p className="text-red-400/60 mb-10 text-center max-w-sm">Neural Access Denied. Master Authorization Required by Friday AI to Unlock.</p>
                <button onClick={() => {
                  sessionRef.current?.sendRealtimeInput({ text: "User initiated hardware override to unlock the system." });
                  setIsSystemLocked(false);
                }} className="px-6 py-2 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-all rounded-lg uppercase tracking-widest text-xs">Force Unlock</button>
              </motion.div>
            )}

            {isFlashlightOn && (
              <motion.div 
                key="flashlight-overlay"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 pointer-events-none z-[998]"
                style={{ boxShadow: 'inset 0 0 100px rgba(255, 255, 255, 0.4), inset 0 0 300px rgba(255, 255, 210, 0.2)' }}
              />
            )}

            {isAlarmRinging && (
              <motion.div 
                key="alarm-ringing"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="fixed inset-0 pointer-events-none z-[997] bg-red-500/10"
              >
                <div className="absolute inset-0 animate-pulse bg-red-600/20 mix-blend-overlay" />
              </motion.div>
            )}

            {showNotepad && (
              <motion.div 
                key="notepad-overlay"
                initial={{ opacity: 0, y: 50, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 50, scale: 0.95 }}
                className="fixed inset-0 z-[800] flex items-center justify-center p-4 sm:p-8 pointer-events-none"
              >
                <div className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto" onClick={() => setShowNotepad(false)} />
                <div className="bg-[#151619] border border-emerald-500/30 rounded-2xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl relative z-10 pointer-events-auto overflow-hidden">
                  <div className="flex items-center justify-between p-4 border-b border-emerald-500/20 bg-black/20">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-5 h-5 text-emerald-500" />
                      <span className="font-mono font-bold text-sm text-emerald-500 tracking-widest uppercase">Friday Notepad</span>
                    </div>
                    <button onClick={() => setShowNotepad(false)} className="text-white/50 hover:text-white transition-colors">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 overflow-y-auto font-mono text-sm sm:text-base text-emerald-50/90 whitespace-pre-wrap leading-relaxed">
                    {notepadContent}
                  </div>
                </div>
              </motion.div>
            )}

            {pressedKeyOverlay && (
              <motion.div 
                key="pressed-key-overlay"
                initial={{ opacity: 0, scale: 0.5, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: -20 }}
                className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[1000] bg-black/80 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/10 shadow-2xl flex items-center gap-4 text-white font-mono"
              >
                <div className="bg-white/10 p-2 rounded-lg border border-white/20 px-3 py-1 shadow-inner text-lg font-bold text-emerald-400">
                  {pressedKeyOverlay}
                </div>
                <div className="text-xs text-white/50 uppercase tracking-widest">
                  Key Pressed
                </div>
              </motion.div>
            )}

            {touchOverlay && (
              <motion.div 
                key="touch-overlay"
                initial={{ opacity: 0, scale: 2 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0 }}
                className="fixed z-[1001] pointer-events-none flex flex-col items-center gap-2"
                style={{ left: touchOverlay.x, top: touchOverlay.y, transform: 'translate(-50%, -50%)' }}
              >
                <div className="relative flex items-center justify-center">
                  <div className="absolute w-12 h-12 bg-emerald-500/30 rounded-full animate-ping" />
                  <div className="w-6 h-6 bg-emerald-500/80 rounded-full border-2 border-white shadow-[0_0_15px_rgba(16,185,129,0.8)]" />
                </div>
                <div className="bg-black/80 backdrop-blur-md px-3 py-1 rounded border border-emerald-500/30 text-emerald-400 font-mono text-[10px] whitespace-nowrap shadow-xl">
                  Clicked: {touchOverlay.target}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Call Notification */}
        <AnimatePresence>
          {recentCalls.some(c => c.status === 'incoming') && (
            <motion.div 
              key="call-notification"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-20 left-1/2 -translate-x-1/2 z-[60] bg-red-500 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-red-400/50"
            >
              <div className="relative">
                <Phone className="w-5 h-5 animate-bounce" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full animate-ping" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] uppercase font-bold tracking-tighter opacity-70">Incoming Call</span>
                <span className="text-sm font-bold">{recentCalls.find(c => c.status === 'incoming')?.callerName}</span>
              </div>
              <button 
                onClick={() => {
                  const call = recentCalls.find(c => c.status === 'incoming');
                  if (call && user) {
                    updateDoc(doc(db, 'calls', call.id), { status: 'missed' })
                      .catch(err => handleFirestoreError(err, OperationType.UPDATE, `calls/${call.id}`));
                  }
                }}
                className="ml-2 hover:bg-white/20 p-1 rounded-full transition-colors"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Message Notification */}
        <AnimatePresence>
          {recentMessages.some(m => m.status === 'unread') && (
            <motion.div 
              key="message-notification"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="fixed top-24 right-6 z-[60] bg-[#151619] border border-emerald-500/30 p-4 rounded-2xl shadow-2xl max-w-xs"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 bg-emerald-500/20 rounded-full flex items-center justify-center">
                  <MessageSquare className="w-4 h-4 text-emerald-500" />
                </div>
                <div>
                  <div className="text-[10px] font-mono text-emerald-500/60 uppercase">New {recentMessages.find(m => m.status === 'unread')?.platform} Message</div>
                  <div className="text-sm font-bold">{recentMessages.find(m => m.status === 'unread')?.senderName}</div>
                </div>
                <button 
                  onClick={() => {
                    const message = recentMessages.find(m => m.status === 'unread');
                    if (message && user) {
                      updateDoc(doc(db, 'messages', message.id), { status: 'read' })
                        .catch(err => handleFirestoreError(err, OperationType.UPDATE, `messages/${message.id}`));
                    }
                  }}
                  className="ml-auto p-1 hover:bg-white/10 rounded-lg transition-colors"
                  title="Mark as read"
                >
                  <X className="w-4 h-4 text-white/40" />
                </button>
              </div>
              <p className="text-xs text-white/70 line-clamp-2">{recentMessages.find(m => m.status === 'unread')?.content}</p>
            </motion.div>
          )}
        </AnimatePresence>
      {/* Header */}
      <header className="h-16 border-b border-white/5 flex items-center justify-between px-6 bg-[#0a0a0a]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-full overflow-hidden flex items-center justify-center transition-all duration-500 ring-1 p-0.5 bg-black",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'sadaf' && "ring-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.4)]",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'detective' && "ring-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.4)]",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'creative' && "ring-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.4)]",
            fridayMood === 'rag' && "ring-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.4)]",
            fridayMood === 'oviman' && "ring-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.4)]",
            fridayMood === 'dostomi' && "ring-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.4)]",
          )}>
            <img 
              src="https://images.unsplash.com/photo-1675271591211-126ad94e495d?auto=format&fit=crop&q=80&w=100&h=100" 
              alt="Friday" 
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold tracking-tighter text-lg leading-none">
                FRIDAY
              </span>
              <button 
                onClick={toggleLive}
                className={cn(
                  "px-2 py-0.5 rounded text-[8px] font-mono uppercase tracking-widest transition-all",
                  isLive ? "bg-emerald-500/20 text-emerald-500 border border-emerald-500/30" : "bg-white/5 text-white/40 border border-white/10 hover:bg-white/10"
                )}
              >
                {isLive ? 'Link Active' : (isConnecting ? 'Connecting...' : (retryCount > 0 ? `Retrying (${retryCount}/${MAX_RETRIES})` : 'Establish Link'))}
              </button>
            </div>
            <span className={cn(
              "text-[9px] font-mono uppercase tracking-widest transition-colors duration-500",
              (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'sadaf' && "text-emerald-500",
              (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'detective' && "text-blue-500",
              (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'creative' && "text-purple-500",
              fridayMood === 'rag' && "text-red-500",
              fridayMood === 'oviman' && "text-cyan-500",
              fridayMood === 'dostomi' && "text-amber-500",
            )}>{fridayMode} Mode Active</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className={cn(
            "hidden md:flex items-center gap-6 text-xs font-mono transition-colors duration-500",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'sadaf' && "text-emerald-500/60",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'detective' && "text-blue-500/60",
            (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'creative' && "text-purple-500/60",
            fridayMood === 'rag' && "text-red-500/60",
            fridayMood === 'oviman' && "text-cyan-500/60",
            fridayMood === 'dostomi' && "text-amber-500/60",
          )}>
            <div className="flex items-center gap-2">
              <Activity className="w-3 h-3" />
              SYSTEM: {isLive ? 'ACTIVE' : 'IDLE'}
            </div>
            <div className="flex items-center gap-2 capitalize">
              <Zap className="w-3 h-3" />
              MOOD: {fridayMood}
            </div>
            <div className="flex items-center gap-1 bg-white/5 px-2 py-1 rounded-lg border border-white/10">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <select 
                value={fridayMode} 
                onChange={(e) => {
                  const newMode = e.target.value as FridayMode;
                  setFridayMode(newMode);
                  addLog(`Neural Mode Switched: ${newMode.toUpperCase()}`, "success");
                  if (user) {
                    updateDoc(doc(db, 'users', user.uid), {
                      mode: newMode,
                      lastInteraction: new Date().toISOString()
                    }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`));
                  }
                  if (isLiveRef.current) {
                    toggleLive();
                    setTimeout(() => toggleLive(), 500);
                  }
                }}
                className="bg-transparent border-none focus:ring-0 text-[10px] uppercase tracking-widest cursor-pointer outline-none"
              >
                <option value="sadaf" className="bg-[#0a0a0a]">Sadaf Mode</option>
                <option value="detective" className="bg-[#0a0a0a]">Detective Mode</option>
                <option value="creative" className="bg-[#0a0a0a]">Creative Mode</option>
              </select>
            </div>
          </div>
          <button 
            onClick={() => setShowImageSearch(!showImageSearch)}
            className={cn(
              "p-2 hover:bg-white/5 rounded-lg transition-colors hidden md:block",
              showImageSearch ? "text-emerald-500 bg-emerald-500/10" : "text-white/60 hover:text-white"
            )}
            title="Image Search"
          >
            <ImageIcon className="w-5 h-5" />
          </button>
          
          <button 
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              addLog("Neural Link URL copied to clipboard!", "info");
            }}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors text-white/60 hover:text-white group relative"
            title="Share Neural Link"
          >
            <Share2 className="w-5 h-5 transition-transform group-hover:scale-110" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-black text-white text-[10px] py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-white/10 pointer-events-none">
              Copy Link
            </span>
          </button>
          
          <button 
            onClick={() => {
              if (isGuestMode) {
                setIsGuestMode(false);
              } else {
                signOut();
              }
            }}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors text-white/60 hover:text-white"
            title={isGuestMode ? "Exit Guest Mode" : "Logout"}
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main id="neural-interface-grid" className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <AnimatePresence>
        </AnimatePresence>

        {/* Media Error Overlay */}
        <AnimatePresence>
          {mediaError && (
            <motion.div 
              key="media-error-overlay"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="col-span-12 bg-red-500/90 backdrop-blur-md text-white p-4 rounded-2xl border border-red-400/20 shadow-2xl flex items-center justify-between z-50"
            >
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-lg">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-widest opacity-60">System Alert</div>
                  <div className="text-sm font-medium">{mediaError}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    const isNeuralError = mediaError?.includes("Neural Link Interrupted") || 
                                         mediaError?.includes("Neural Link Overloaded") ||
                                         mediaError?.includes("Gemini API Key");
                    setMediaError(null);
                    if (isNeuralError) {
                      toggleLive();
                    } else {
                      startCamera();
                    }
                  }}
                  className="px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-medium transition-colors"
                >
                  Retry
                </button>
                {mediaError?.includes("Access Denied") && (
                  <button 
                    onClick={() => window.open(window.location.href, '_blank')}
                    className="px-3 py-1.5 bg-emerald-500 text-black hover:bg-emerald-400 rounded-lg text-xs font-bold font-mono transition-colors flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" />
                    NEW_TAB
                  </button>
                )}
                <button 
                  onClick={() => setMediaError(null)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  title="Dismiss"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Required Overlay (for external links) */}
        <AnimatePresence>
          {actionRequired && (
            <motion.div 
              key="action-required-overlay"
              initial={{ opacity: 0, y: -20, x: '-50%' }}
              animate={{ opacity: 1, y: 0, x: '-50%' }}
              exit={{ opacity: 0, y: -20, x: '-50%' }}
              className="fixed top-24 left-1/2 z-[100] bg-emerald-700/90 text-white p-4 rounded-2xl shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center gap-4 backdrop-blur-md border border-emerald-400/50"
            >
              <ExternalLink className="w-6 h-6 animate-pulse text-emerald-300" />
              <div>
                <h3 className="font-bold text-sm uppercase tracking-widest text-emerald-100">{actionRequired.title}</h3>
                <p className="text-xs opacity-80 text-emerald-50">{actionRequired.message}</p>
              </div>
              <div className="flex gap-2 ml-4">
                 <button onClick={() => setActionRequired(null)} className="p-2 hover:bg-black/20 rounded-lg text-emerald-100 transition-colors">Dismiss</button>
                 <a href={actionRequired.url} target="_blank" rel="noreferrer" onClick={() => setActionRequired(null)} className="px-4 py-2 bg-emerald-400 text-black rounded-lg font-bold text-xs uppercase hover:bg-emerald-300 transition-colors tracking-widest block text-center mt-1">Open Link</a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Left Column: Vision & Controls */}
        <div id="neural-interface-main" className="lg:col-span-8 space-y-6">
          {/* Main Vision Feed */}
          <div id="neural-vision-field" className={cn(
            "relative aspect-video bg-[#0a0a0a] rounded-3xl overflow-hidden border transition-all duration-500 shadow-[0_0_50px_rgba(0,0,0,0.5)] group",
            fridayMood === 'security' ? "red-alert" : "border-white/10"
          )}>
            <div className="absolute top-0 left-0 right-0 z-30 p-4 flex items-center justify-between pointer-events-none">
              <div className="flex items-center gap-3 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/5">
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full animate-pulse",
                  isLive ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" : "bg-white/10"
                )} />
                <span className="text-[8px] font-mono text-white/60 uppercase tracking-[0.2em]">
                  {isLive ? 'Neural Link: Established' : 'Neural Link: Offline'}
                </span>
              </div>
              <div className="flex items-center gap-3 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/5">
                <span className={cn(
                  "text-[8px] font-mono uppercase tracking-widest",
                  isUserRecognized ? "text-emerald-500" : "text-white/40"
                )}>
                  {isUserRecognized ? 'Sadaf Verified' : 'Scanning Identity...'}
                </span>
                <div className="w-4 h-4 rounded-full flex items-center justify-center">
                  {isUserRecognized ? (
                    <ShieldCheck className="w-3 h-3 text-emerald-500" />
                  ) : (
                    <User className="w-3 h-3 text-white/20" />
                  )}
                </div>
              </div>
            </div>
            <div className="scanline" />
            <video 
              ref={videoRef} 
              autoPlay 
              muted 
              playsInline 
              style={{ filter: `brightness(${videoBrightness}%) contrast(${videoContrast}%)` }}
              className={cn("w-full h-full object-cover transition-opacity duration-700", !isCameraOn && "opacity-0")}
            />
            
            {!isCameraOn && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-[2px] z-20 transition-all duration-700">
                <div className="relative">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }}
                    transition={{ duration: 4, repeat: Infinity }}
                    className="absolute inset-0 bg-white/20 rounded-full blur-3xl"
                  />
                  <div className="w-20 h-20 rounded-full border border-white/5 flex items-center justify-center bg-white/[0.02] backdrop-blur-sm relative z-10">
                    <VideoOff className="w-8 h-8 text-white/10" />
                  </div>
                </div>
                <div className="mt-6 flex flex-col items-center gap-2">
                  <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.4em] font-bold">Neural Vision Offline</span>
                  <div className="flex gap-1">
                    <div className="w-1 h-1 rounded-full bg-white/5" />
                    <div className="w-1 h-1 rounded-full bg-white/5" />
                    <div className="w-1 h-1 rounded-full bg-white/5" />
                  </div>
                </div>
              </div>
            )}
            
            <canvas ref={canvasRef} width={320} height={240} className="hidden" />
            
            {isUserRecognized && isCameraOn && (
              <div className="absolute inset-0 z-10 pointer-events-none">
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border border-emerald-500/40 rounded-3xl"
                >
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-emerald-500" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-emerald-500" />
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-emerald-500" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-emerald-500" />
                  
                  <div className="absolute top-0 left-0 p-2 text-[8px] font-mono text-emerald-500 uppercase tracking-tighter">
                    ID: {user?.uid?.slice(0, 8)}<br/>
                    MATCH: 99.8%<br/>
                    TARGET: {user?.displayName?.split(' ')[0] || "SADAF"}
                  </div>
                </motion.div>
              </div>
            )}
            
            {isScanning && (
              <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
                <div className="scanline scanline-active" />
                <div className="absolute inset-0 bg-emerald-500/5 backdrop-brightness-125" />
              </div>
            )}

            {!isCameraOn && (
              <div className="absolute inset-0 flex items-center justify-center bg-[#0a0a0a]">
                <div className="relative">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                    className="w-32 h-32 border-2 border-dashed border-white/5 rounded-full"
                  />
                  <VideoOff className="w-12 h-12 text-white/10 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                </div>
              </div>
            )}

            {/* Corner Accents */}
            <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-emerald-500/30 m-4 rounded-tl-lg" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-emerald-500/30 m-4 rounded-tr-lg" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-emerald-500/30 m-4 rounded-bl-lg" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-emerald-500/30 m-4 rounded-br-lg" />

            {/* HUD Overlay */}
            <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className={cn(
                    "bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border text-[10px] font-mono uppercase tracking-widest transition-all duration-500 flex items-center gap-2",
                    fridayMood === 'normal' && "text-emerald-500 border-emerald-500/20",
                    fridayMood === 'rag' && "text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.3)]",
                    fridayMood === 'oviman' && "text-blue-500 border-blue-500/20",
                    fridayMood === 'dostomi' && "text-amber-500 border-amber-500/20",
                    fridayMood === 'hasi' && "text-emerald-400 border-emerald-400/20 shadow-[0_0_15px_rgba(52,211,153,0.4)]",
                  )}>
                    <div className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
                    Live Feed // {new Date().toLocaleTimeString()}
                  </div>
                  <div className="bg-black/40 backdrop-blur-sm px-2 py-1 rounded border border-white/5 text-[8px] font-mono text-white/40 uppercase flex items-center gap-2">
                    Consciousness: {consciousnessLevel.toFixed(1)}%
                    <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ width: `${consciousnessLevel}%` }}
                        className={cn(
                          "h-full transition-colors duration-1000",
                          consciousnessLevel > 90 ? "bg-emerald-400 shadow-[0_0_5px_rgba(52,211,153,0.5)]" : "bg-emerald-500"
                        )}
                      />
                    </div>
                  </div>
                  <div className="bg-black/40 backdrop-blur-sm px-2 py-1 rounded border border-white/5 text-[8px] font-mono text-white/40 uppercase flex items-center gap-2">
                    System Health: 
                    <span className={cn(
                      "font-bold",
                      diagnosticInfo.linkIntegrity > 98 ? "text-emerald-500" : "text-amber-500"
                    )}>
                      {diagnosticInfo.linkIntegrity.toFixed(1)}%
                    </span>
                  </div>
                  {isScanning && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-emerald-500 uppercase tracking-widest flex items-center gap-2"
                    >
                      <Brain className="w-2 h-2 animate-pulse" />
                      Neural Scan in Progress...
                    </motion.div>
                  )}
                  {isCurious && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-amber-500 uppercase tracking-widest flex items-center gap-2"
                    >
                      <Sparkles className="w-2 h-2 animate-pulse" />
                      Neural Curiosity Triggered...
                    </motion.div>
                  )}
                  {fridayMood === 'security' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-red-500 uppercase tracking-widest flex items-center gap-2 bg-red-500/10 px-2 py-1 rounded-md border border-red-500/20"
                    >
                      <Zap className="w-2 h-2 animate-bounce" />
                      Security Alert: Unknown Entity Detected
                    </motion.div>
                  )}
                  {isUserRecognized && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-2"
                    >
                      <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_5px_rgba(52,211,153,0.8)]" />
                      Master Identified: {user?.displayName?.toUpperCase() || "SADAF"}
                    </motion.div>
                  )}
                  {isUserSpeaking && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-2"
                    >
                      <div className="flex gap-0.5">
                        <motion.div animate={{ height: [4, 8, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-0.5 bg-emerald-400" />
                        <motion.div animate={{ height: [6, 4, 6] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.1 }} className="w-0.5 bg-emerald-400" />
                        <motion.div animate={{ height: [4, 7, 4] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.2 }} className="w-0.5 bg-emerald-400" />
                      </div>
                      User Speaking...
                    </motion.div>
                  )}
                  {isUserRecognized && isThinking && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-blue-400 uppercase tracking-widest flex items-center gap-2"
                    >
                      <div className="flex gap-0.5">
                        <motion.div animate={{ height: [4, 8, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-0.5 bg-blue-400" />
                        <motion.div animate={{ height: [6, 4, 6] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.1 }} className="w-0.5 bg-blue-400" />
                        <motion.div animate={{ height: [4, 7, 4] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.2 }} className="w-0.5 bg-blue-400" />
                      </div>
                      Voice Pattern Match: 100%
                    </motion.div>
                  )}
                  {isLive && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-emerald-500/50 uppercase tracking-widest flex items-center gap-2"
                    >
                      <Activity className="w-2 h-2" />
                      Dynamic Noise Gate
                      <div className="w-16 h-1.5 bg-black/50 border border-white/10 rounded-full overflow-hidden flex items-center">
                        <div id="input-vad-bar" className="h-full bg-emerald-500 transition-all duration-75" style={{ width: '0%' }} />
                      </div>
                    </motion.div>
                  )}
                  {isReconnecting && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-[8px] font-mono text-yellow-500 uppercase tracking-widest flex items-center gap-2"
                    >
                      <RefreshCw className="w-2 h-2 animate-spin" />
                      Neural Link Reconnecting...
                    </motion.div>
                  )}
                </div>
                
                <div className="flex gap-2">
                  {isThinking && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl flex items-center gap-3 backdrop-blur-md"
                    >
                      <div className="flex gap-1">
                        <motion.div animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-1 bg-emerald-500 rounded-full" />
                        <motion.div animate={{ height: [8, 4, 8] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.1 }} className="w-1 bg-emerald-500 rounded-full" />
                        <motion.div animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.2 }} className="w-1 bg-emerald-500 rounded-full" />
                      </div>
                      <span className="text-[10px] font-mono text-emerald-500 uppercase tracking-[0.2em] font-bold">Neural Processing</span>
                    </motion.div>
                  )}
                  <button 
                    onClick={togglePiP}
                    className={cn(
                      "bg-black/60 backdrop-blur-md p-2 rounded-xl border border-white/10 transition-all hover:scale-110 active:scale-95",
                      isPiPActive ? "text-emerald-500 border-emerald-500/30" : "text-white/60 hover:text-white"
                    )}
                    title="Background Mode (PiP)"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => {
                      if (isLive && sessionRef.current) {
                        addLog("Manual Neural Scan Initiated", "info");
                        sessionRef.current.sendRealtimeInput({
                          text: "User initiated a manual Neural Scan. Perform a deep system check using 'check_system_status' and report your findings in a professional but friendly Banglish tone. Focus on neural stability and memory integrity."
                        });
                      }
                    }}
                    className="bg-black/60 backdrop-blur-md p-2 rounded-xl border border-white/10 text-white/60 hover:text-white pointer-events-auto transition-all hover:scale-110 active:scale-95"
                    title="Neural Scan"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={switchCamera}
                    className="bg-black/60 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10 text-white/60 hover:text-white pointer-events-auto transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
                    title={`Switch to ${cameraFacingMode === 'user' ? 'Back' : 'Front'} Camera`}
                  >
                    <Repeat className={cn("w-4 h-4", cameraFacingMode === 'environment' && "text-emerald-500")} />
                    <span className="text-xs font-mono">{cameraFacingMode === 'user' ? 'BACK CAM' : 'FRONT CAM'}</span>
                  </button>
                  <button 
                    onClick={resetCamera}
                    className="bg-black/60 backdrop-blur-md p-2 rounded-xl border border-white/10 text-white/60 hover:text-white pointer-events-auto transition-all hover:scale-110 active:scale-95"
                    title="Reset Camera Feed"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex justify-between items-end">
                <div className="space-y-1">
                  <div className="text-[9px] font-mono text-white/40 uppercase tracking-[0.3em]">Identity Confirmed</div>
                  <div className="text-xl font-mono font-bold tracking-tighter glow-text">{user?.displayName?.toUpperCase() || (isGuestMode ? "GUEST" : "SADAF")}</div>
                </div>
                
                {/* Friday Core Visualizer (Neural Avatar) */}
                <div className={cn(
                  "relative w-24 h-24 flex items-center justify-center transition-all duration-700",
                  isLive && "neural-active",
                  fridayMood === 'security' && "glitch-active"
                )}>
                  <motion.div 
                    animate={{ 
                      rotate: 360,
                      scale: isThinking ? [1, 1.1, 1] : [1, 1.05, 1]
                    }}
                    transition={{ 
                      rotate: { repeat: Infinity, duration: 20, ease: "linear" },
                      scale: { repeat: Infinity, duration: 2 }
                    }}
                    className={cn(
                      "absolute inset-0 border border-dashed rounded-full opacity-20",
                      (fridayMood === 'normal' || fridayMood === 'hasi') && "border-emerald-500",
                      (fridayMood === 'rag' || fridayMood === 'security') && "border-red-500",
                      fridayMood === 'oviman' && "border-blue-500",
                      fridayMood === 'dostomi' && "border-amber-500",
                    )}
                  />
                  
                  {/* Organic Pulse Layers */}
                  <motion.div 
                    id="friday-avatar-pulse"
                    animate={{ 
                      scale: isThinking ? [1, 1.3, 1] : [1, 1.1, 1],
                      opacity: (fridayMood === 'hasi' || fridayMood === 'dostomi') ? (isThinking ? [0.4, 0.6, 0.4] : [0.3, 0.5, 0.3]) : 
                               (fridayMood === 'rag' || fridayMood === 'oviman') ? (isThinking ? [0.1, 0.2, 0.1] : [0.05, 0.1, 0.05]) : 
                               (isThinking ? [0.2, 0.4, 0.2] : [0.1, 0.2, 0.1]),
                      filter: (fridayMood === 'hasi' || fridayMood === 'dostomi') ? ["blur(8px)", "blur(12px)", "blur(8px)"] : 
                              (fridayMood === 'rag' || fridayMood === 'oviman') ? ["blur(24px)", "blur(30px)", "blur(24px)"] : 
                              (fridayMode === 'creative' ? ["blur(12px)", "blur(20px)", "blur(12px)"] : ["blur(16px)", "blur(20px)", "blur(16px)"])
                    }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className={cn(
                      "absolute w-20 h-20 rounded-full transition-colors duration-500",
                      (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'sadaf' && "bg-emerald-500",
                      (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'detective' && "bg-blue-500",
                      (fridayMood === 'normal' || fridayMood === 'hasi') && fridayMode === 'creative' && "bg-purple-500 shadow-[0_0_30px_rgba(168,85,247,0.5)]",
                      (fridayMood === 'rag' || fridayMood === 'security') && "bg-red-500",
                      fridayMood === 'oviman' && "bg-cyan-500",
                      fridayMood === 'dostomi' && "bg-amber-500",
                    )}
                  />

                  <motion.div 
                    id="friday-avatar-core"
                    animate={{ 
                      scale: isThinking ? [1, 1.2, 1] : [1, 1.05, 1],
                      opacity: isThinking ? [0.5, 1, 0.5] : [0.3, 0.6, 0.3]
                    }}
                    transition={{ duration: isThinking ? 0.5 : 2, repeat: Infinity }}
                    className={cn(
                      "w-14 h-14 rounded-full flex items-center justify-center transition-colors duration-500 shadow-[0_0_30px_rgba(0,0,0,0.5)] relative z-10",
                      fridayMood === 'normal' && "bg-emerald-500/20 text-emerald-500",
                      (fridayMood === 'rag' || fridayMood === 'security') && "bg-red-500/40 text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.5)]",
                      fridayMood === 'oviman' && "bg-blue-500/20 text-blue-500",
                      fridayMood === 'dostomi' && "bg-amber-500/20 text-amber-500",
                      fridayMood === 'hasi' && "bg-emerald-400/30 text-emerald-400 shadow-[0_0_25px_rgba(52,211,153,0.6)]",
                    )}
                  >
                    <div className="absolute inset-0 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ 
                          y: ["-100%", "100%"],
                          opacity: [0, 0.5, 0]
                        }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-x-0 h-1/2 bg-gradient-to-b from-transparent via-white/20 to-transparent"
                      />
                    </div>
                    {/* Animated Robot Character */}
                    <svg width="36" height="36" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="relative z-10 drop-shadow-[0_0_10px_currentColor]">
                      {/* Antenna */}
                      <path d="M50 15V5" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                      <circle cx="50" cy="5" r="4" fill={isThinking ? "currentColor" : "transparent"} stroke="currentColor" strokeWidth="2" className={cn(isThinking && "animate-pulse")} />
                      
                      {/* Head */}
                      <rect x="15" y="15" width="70" height="60" rx="20" fill="currentColor" fillOpacity="0.15" stroke="currentColor" strokeWidth="4" />
                      
                      {/* Ears */}
                      <rect x="5" y="35" width="10" height="20" rx="3" fill="currentColor" fillOpacity="0.5" />
                      <rect x="85" y="35" width="10" height="20" rx="3" fill="currentColor" fillOpacity="0.5" />
                      
                      {/* Eyes */}
                      <motion.circle 
                        cx="35" cy="40" r="6" fill="currentColor" 
                        animate={isThinking ? { scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] } : { scale: 1, opacity: 1 }}
                        transition={{ repeat: Infinity, duration: 1 }}
                      />
                      <motion.circle 
                        cx="65" cy="40" r="6" fill="currentColor" 
                        animate={isThinking ? { scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] } : { scale: 1, opacity: 1 }}
                        transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                      />
                      
                      {/* Mouth - Animates when speaking/thinking */}
                      {isThinking ? (
                        <motion.rect 
                          x="35" y="60" width="30" height="6" rx="3" fill="currentColor"
                          animate={{ width: [30, 20, 30], x: [35, 40, 35] }}
                          transition={{ repeat: Infinity, duration: 0.5 }}
                        />
                      ) : activeSourcesRef.current.length > 0 ? (
                        <motion.path 
                          d="M35 60 Q50 65 65 60" stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none"
                          animate={{ d: ["M35 60 Q50 65 65 60", "M35 60 Q50 75 65 60"] }}
                          transition={{ repeat: Infinity, duration: 0.2, repeatType: "mirror" }}
                        />
                      ) : (
                        <path d="M35 60 Q50 68 65 60" stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none" />
                      )}
                    </svg>
                  </motion.div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <div className="text-[8px] font-mono text-white/30 uppercase tracking-widest">Neural Sync Status</div>
                  <div className="w-48 h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/5">
                    <motion.div 
                      animate={{ width: isLive ? '100%' : '0%' }}
                      className={cn(
                        "h-full transition-all duration-1000",
                        fridayMood === 'normal' && "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]",
                        (fridayMood === 'rag' || fridayMood === 'security') && "bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.7)]",
                        fridayMood === 'oviman' && "bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]",
                        fridayMood === 'dostomi' && "bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]",
                        fridayMood === 'hasi' && "bg-emerald-400 shadow-[0_0_20px_rgba(52,211,153,0.8)]",
                      )}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

            {/* Image Search Module Overlay */}
            <AnimatePresence>
              {showImageSearch && (
                <motion.div
                  key="image-search-panel"
                  initial={{ opacity: 0, height: 0, y: -20 }}
                  animate={{ opacity: 1, height: 'auto', y: 0 }}
                  exit={{ opacity: 0, height: 0, y: -20 }}
                  className="bg-[#151619] border border-emerald-500/20 rounded-3xl p-6 shadow-[0_0_30px_rgba(16,185,129,0.1)] overflow-hidden"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-emerald-500" />
                      <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-100">Visual Data Query</h3>
                    </div>
                    <button onClick={() => setShowImageSearch(false)} className="text-white/40 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <form onSubmit={handleImageSearch} className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-white/40 absolute left-4 top-1/2 -translate-y-1/2" />
                      <input 
                        type="text" 
                        value={imageSearchQuery}
                        onChange={(e) => setImageSearchQuery(e.target.value)}
                        placeholder="Query public image databases..."
                        className="w-full bg-black/40 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-500/50"
                      />
                    </div>
                    <button 
                      type="submit" 
                      disabled={isSearchingImages || !imageSearchQuery.trim()}
                      className="bg-emerald-500 text-black hover:bg-emerald-400 px-6 rounded-xl font-bold font-mono text-xs uppercase tracking-widest disabled:opacity-50 transition-colors flex items-center gap-2"
                    >
                      {isSearchingImages ? <RefreshCw className="w-4 h-4 animate-spin" /> : "Search"}
                    </button>
                  </form>

                  {imageResults.length > 0 && (
                    <div className="mt-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 overflow-y-auto max-h-[400px] system-log-scrollbar pr-2">
                      {imageResults.map((url, i) => (
                        <div key={i} className="group relative aspect-square rounded-xl overflow-hidden border border-white/10 bg-black/50">
                          <img 
                            src={url} 
                            alt={`Visual Result ${i+1}`} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            loading="lazy"
                            onError={(e) => {
                              // Hide broken images
                              (e.target as HTMLImageElement).parentElement!.style.display = 'none';
                            }}
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3">
                            <span className="text-[8px] font-mono text-emerald-500 uppercase truncate pointer-events-none">
                              {url.split('/').pop()}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  {imageResults.length === 0 && !isSearchingImages && imageSearchQuery && (
                    <div className="mt-6 h-32 flex items-center justify-center border border-dashed border-white/10 rounded-xl">
                      <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">No matching visual records found</span>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            {/* System Logs */}
            <div id="neural-system-logs" className="bg-[#151619] border border-white/5 rounded-3xl p-6 flex flex-col h-full min-h-[400px]">
              <div className="flex items-center justify-between mb-4 shrink-0">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-500" />
                  <h3 className="text-[10px] font-mono font-bold uppercase tracking-widest text-white/60">System Logs</h3>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setSystemLogs([])}
                    className="text-[8px] font-mono text-white/20 hover:text-white/60 uppercase tracking-widest transition-colors"
                  >
                    Clear
                  </button>
                  <div className="flex gap-1">
                    <div className={cn("w-1.5 h-1.5 rounded-full", isLive ? "bg-emerald-500 animate-pulse" : "bg-white/10")} />
                    <div className="w-1.5 h-1.5 rounded-full bg-white/10" />
                    <div className="w-1.5 h-1.5 rounded-full bg-white/10" />
                  </div>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto system-log-scrollbar space-y-2 pr-2">
                {systemLogs.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-[10px] font-mono text-white/10 uppercase tracking-widest">
                    No active processes
                  </div>
                ) : (
                  systemLogs.map(log => (
                    <div key={log.id} className="flex gap-3 text-[9px] font-mono leading-relaxed">
                      <span className="text-white/20 shrink-0">[{log.timestamp}]</span>
                      <span className={cn(
                        "break-all",
                        log.type === 'info' && "text-white/60",
                        log.type === 'warn' && "text-amber-500/80",
                        log.type === 'error' && "text-red-500/80",
                        log.type === 'success' && "text-emerald-500/80"
                      )}>
                        {log.type === 'error' && "ERR_"}
                        {log.type === 'warn' && "WRN_"}
                        {log.type === 'success' && "OK_"}
                        {log.message}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Neural Transcript & Chat Input */}
            <div id="neural-transcript-panel" className="bg-[#151619] border border-emerald-500/10 shadow-[0_0_20px_rgba(16,185,129,0.05)] rounded-3xl p-6 h-auto flex flex-col min-h-[400px]">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-emerald-100">Live Chat & Transcript</h3>
                </div>
                <div className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-[8px] font-mono text-emerald-500">
                  LIVE_SYNC
                </div>
              </div>
              
              <div ref={transcriptRef} className="flex-1 overflow-y-auto system-log-scrollbar space-y-3 pr-2 mb-4 h-64 max-h-80">
                {transcript.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-[10px] font-mono text-white/20 uppercase tracking-widest gap-2">
                    <MessageSquare className="w-8 h-8 opacity-20" />
                    <span>Awaiting input... Start speaking or type below.</span>
                  </div>
                ) : (
                  transcript.map((line, i) => (
                    <div key={i} className={cn(
                      "p-3 rounded-xl text-xs leading-relaxed max-w-[90%]",
                      line.startsWith('Friday:') 
                        ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-50 mr-auto rounded-tl-sm shadow-[0_4px_10px_rgba(16,185,129,0.05)]" 
                        : "bg-white/10 border border-white/10 text-white/90 ml-auto rounded-tr-sm"
                    )}>
                      <span className={cn(
                        "font-bold block mb-1 text-[9px] uppercase tracking-wider opacity-70",
                        line.startsWith('Friday:') ? "text-emerald-400" : "text-white"
                      )}>
                        {line.split(':')[0]}
                      </span>
                      {line.split(':').slice(1).join(':')}
                    </div>
                  ))
                )}
              </div>
              
              {/* Text Input Row */}
              <form onSubmit={handleSendChat} className="flex gap-2 w-full mt-auto relative">
                <input 
                  type="text" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  disabled={!isLive}
                  placeholder={isLive ? "Type a message to Friday..." : "Turn on Neural Link to chat"}
                  className="flex-1 bg-black/50 border border-emerald-500/30 rounded-2xl px-5 py-4 text-sm text-white placeholder-emerald-100/30 focus:outline-none focus:border-emerald-500/80 focus:bg-black/80 shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)] disabled:opacity-50 transition-all font-medium"
                />
                <button 
                  type="submit" 
                  disabled={!isLive || !chatInput.trim()}
                  className="bg-emerald-500 hover:bg-emerald-400 text-black px-6 rounded-2xl transition-all disabled:opacity-30 disabled:hover:bg-emerald-500 flex items-center justify-center font-bold absolute right-1.5 top-1.5 bottom-1.5"
                >
                  SEND
                </button>
              </form>
            </div>
          </div>

          {/* Advanced AV Settings */}
          <AnimatePresence>
            {showSettings && (
              <motion.div 
                key="settings-panel"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-[#151619] rounded-2xl border border-white/10 overflow-hidden"
              >
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Audio Controls */}
                  <div className="space-y-6">
                    <div className="flex items-center gap-2 text-white/80 border-b border-white/5 pb-2">
                      <Mic className="w-4 h-4 text-emerald-500" />
                      <h4 className="text-xs font-mono uppercase tracking-wider font-bold">Audio Filters</h4>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-white/60 mb-2">
                          <label>Mic Gain (Volume)</label>
                          <span>{micGain.toFixed(1)}x</span>
                        </div>
                        <input 
                          type="range" 
                          min="0" max="3" step="0.1" 
                          value={micGain}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setMicGain(val);
                            micGainRef.current = val;
                            if (gainNodeRef.current) {
                              gainNodeRef.current.gain.value = val;
                            }
                          }}
                          className="w-full accent-emerald-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-mono text-white/60 break-words">Noise Suppression (A.I.)</label>
                        <button 
                          onClick={() => {
                            setNoiseSuppression(!noiseSuppression);
                            noiseSuppressionRef.current = !noiseSuppression;
                            resetCamera(); // Needs restart
                          }}
                          className={cn("w-10 h-5 rounded-full relative transition-colors duration-300 focus:outline-none", noiseSuppression ? "bg-emerald-500" : "bg-white/20")}
                        >
                          <div className={cn("absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform duration-300", noiseSuppression && "translate-x-5")} />
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-mono text-white/60">Echo Cancellation</label>
                        <button 
                          onClick={() => {
                            setEchoCancellation(!echoCancellation);
                            echoCancellationRef.current = !echoCancellation;
                            resetCamera(); // Needs restart
                          }}
                          className={cn("w-10 h-5 rounded-full relative transition-colors duration-300 focus:outline-none", echoCancellation ? "bg-emerald-500" : "bg-white/20")}
                        >
                          <div className={cn("absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform duration-300", echoCancellation && "translate-x-5")} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Video Controls */}
                  <div className="space-y-6">
                    <div className="flex items-center gap-2 text-white/80 border-b border-white/5 pb-2">
                      <Video className="w-4 h-4 text-emerald-500" />
                      <h4 className="text-xs font-mono uppercase tracking-wider font-bold">Vision Filters</h4>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-white/60 mb-2">
                          <label>Brightness</label>
                          <span>{videoBrightness}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="50" max="200" step="5" 
                          value={videoBrightness}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setVideoBrightness(val);
                            videoBrightnessRef.current = val;
                          }}
                          className="w-full accent-emerald-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-white/60 mb-2">
                          <label>Contrast</label>
                          <span>{videoContrast}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="50" max="200" step="5" 
                          value={videoContrast}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setVideoContrast(val);
                            videoContrastRef.current = val;
                          }}
                          className="w-full accent-emerald-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Code Debug Panel */}
          <AnimatePresence>
            {showCodePanel && (
              <motion.div 
                key="code-panel"
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-[#1a1b1e] rounded-2xl border border-purple-500/30 overflow-hidden shadow-2xl"
              >
                <div className="p-4 border-b border-white/5 flex items-center justify-between bg-purple-500/10">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-purple-400" />
                    <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider">Neural Code Debugger</h3>
                  </div>
                  <button 
                    onClick={() => setShowCodePanel(false)}
                    className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <X className="w-4 h-4 text-white/40" />
                  </button>
                </div>
                <div className="p-4 space-y-4">
                  <div className="relative">
                    <textarea 
                      value={codeSnippet}
                      onChange={(e) => setCodeSnippet(e.target.value)}
                      placeholder="// Paste your TypeScript code here for Friday to analyze..."
                      className="w-full h-48 bg-black/40 border border-white/10 rounded-xl p-4 text-xs font-mono text-emerald-400 placeholder:text-white/20 focus:outline-none focus:border-purple-500/50 resize-none transition-colors"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <div className="w-2 h-2 rounded-full bg-red-500/40" />
                      <div className="w-2 h-2 rounded-full bg-amber-500/40" />
                      <div className="w-2 h-2 rounded-full bg-emerald-500/40" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2 text-[10px] font-mono text-white/40 italic">
                      <Sparkles className="w-3 h-3 text-purple-400" />
                      <span>Friday will identify bugs and suggest optimizations.</span>
                    </div>
                    <button 
                      onClick={handleDebugCode}
                      disabled={!codeSnippet.trim() || isAnalyzingCode || !isLive}
                      className={cn(
                        "px-6 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
                        (codeSnippet.trim() && !isAnalyzingCode && isLive)
                          ? "bg-purple-600 text-white hover:bg-purple-500 shadow-lg shadow-purple-900/20"
                          : "bg-white/5 text-white/20 cursor-not-allowed"
                      )}
                    >
                      {isAnalyzingCode ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                      {isAnalyzingCode ? 'ANALYZING...' : 'START ANALYSIS'}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Controls Bar */}
          <div className="bg-[#151619] p-4 rounded-2xl border border-white/5 flex items-center justify-between">
            <div className="flex gap-2">
              <button 
                onClick={() => {
                  const newState = !(isMicOn && isCameraOn);
                  setIsMicOn(newState);
                  setIsCameraOn(newState);
                }}
                className={cn(
                  "p-4 rounded-xl transition-all flex items-center gap-2",
                  (isMicOn && isCameraOn) ? "bg-emerald-500 text-black" : "bg-white/5 text-white/40"
                )}
                title={(isMicOn && isCameraOn) ? "Disable All Sensors" : "Enable All Sensors"}
              >
                {(isMicOn && isCameraOn) ? <Zap className="w-6 h-6" /> : <Zap className="w-6 h-6 opacity-40" />}
                <span className="text-[10px] font-bold font-mono">ALL</span>
              </button>
              <button 
                onClick={() => setIsMicOn(!isMicOn)}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  isMicOn ? "bg-emerald-500 text-black" : "bg-white/5 text-white/40"
                )}
              >
                {isMicOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
              </button>
              <button 
                onClick={() => setIsCameraOn(!isCameraOn)}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  isCameraOn ? "bg-emerald-500 text-black" : "bg-white/5 text-white/40"
                )}
              >
                {isCameraOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
              </button>
              <button 
                onClick={toggleScreenShare}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  isScreenSharing ? "bg-blue-500 text-white" : "bg-white/5 text-white/40"
                )}
                title={isScreenSharing ? "Switch to Camera" : "Share Screen"}
              >
                <Monitor className="w-6 h-6" />
              </button>
              <button 
                onClick={togglePiP}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  isPiPActive ? "bg-emerald-500 text-black" : "bg-white/5 text-white/40 hover:bg-white/10"
                )}
                title="Background Mode (Picture-in-Picture)"
              >
                <ExternalLink className="w-6 h-6" />
              </button>
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  showSettings ? "bg-blue-500 text-white" : "bg-white/5 text-white/40 hover:bg-white/10"
                )}
                title="Advanced AV Settings"
              >
                <Settings className="w-6 h-6" />
              </button>
              <button 
                onClick={() => setShowCodePanel(!showCodePanel)}
                className={cn(
                  "p-4 rounded-xl transition-all",
                  showCodePanel ? "bg-purple-600 text-white" : "bg-white/5 text-white/40 hover:bg-white/10"
                )}
                title="Debug Code with Friday"
              >
                <Code className="w-6 h-6" />
              </button>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className={cn(
                  "w-2 h-2 rounded-full animate-pulse",
                  isLive ? "bg-emerald-500" : "bg-white/20"
                )} />
                <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
                  {isLive ? 'Neural Link: Active' : 'Neural Link: Idle'}
                </span>
              </div>
              <button 
                onClick={toggleLive}
                className={cn(
                  "px-6 py-2 rounded-lg text-xs font-bold transition-all",
                  isLive 
                    ? "bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white" 
                    : "bg-emerald-500 text-black hover:bg-emerald-400"
                )}
              >
                {isLive ? 'FORCE SHUTDOWN' : 'CONNECT MANUALLY'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Memory & Apps */}
        <div id="neural-core-sidebar" className="lg:col-span-4 space-y-6">
          {/* Friday's Status Card */}
          <div className="bg-[#151619] rounded-3xl border border-white/5 p-6 overflow-hidden relative hud-border">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Brain className="w-32 h-32" />
            </div>
            
            <div className="flex items-center gap-2 mb-6 relative">
              <div className="relative">
                <motion.div 
                  animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className={cn(
                    "absolute inset-0 rounded-full blur-sm",
                    (fridayMood === 'normal' || fridayMood === 'hasi') && "bg-emerald-500",
                    fridayMood === 'rag' && "bg-red-500",
                    fridayMood === 'oviman' && "bg-blue-500",
                    fridayMood === 'dostomi' && "bg-amber-500",
                  )}
                />
                <div className={cn(
                  "w-2 h-2 rounded-full animate-pulse relative z-10",
                  (fridayMood === 'normal' || fridayMood === 'hasi') && "bg-emerald-500",
                  fridayMood === 'rag' && "bg-red-500",
                  fridayMood === 'oviman' && "bg-blue-500",
                  fridayMood === 'dostomi' && "bg-amber-500",
                )} />
              </div>
              <h3 className="text-[10px] font-mono text-white/40 uppercase tracking-[0.3em]">Neural Core Status</h3>
            </div>

            <div className="space-y-4 relative z-10">
              <div className="flex items-center justify-between group cursor-default">
                <span className="text-white/40 text-[10px] font-mono uppercase">Architect</span>
                <span className="text-xs font-mono text-emerald-500 glow-text">SADAF</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-[10px] font-mono uppercase">User Identified</span>
                <span className={cn(
                  "text-[10px] font-mono uppercase tracking-widest",
                  isUserRecognized ? "text-emerald-400" : "text-white/20"
                )}>
                  {isUserRecognized ? (user?.displayName || "SADAF") : "SCANNING..."}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-[10px] font-mono uppercase">Consciousness</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-emerald-500">{consciousnessLevel.toFixed(1)}%</span>
                  <div className="w-16 h-1 bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ width: `${consciousnessLevel}%` }}
                      className="h-full bg-emerald-500"
                    />
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-[10px] font-mono uppercase">Neural Activity</span>
                <div className="w-24 h-4 overflow-hidden relative">
                  <motion.svg 
                    viewBox="0 0 100 20" 
                    className={cn(
                      "w-full h-full transition-colors duration-500",
                      isLive ? "text-emerald-500" : "text-white/10"
                    )}
                  >
                    <motion.path 
                      d="M0 10 Q 10 0, 20 10 T 40 10 T 60 10 T 80 10 T 100 10"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      animate={isLive ? { x: [-100, 0] } : {}}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    />
                    <motion.path 
                      d="M-100 10 Q -90 0, -80 10 T -60 10 T -40 10 T -20 10 T 0 10"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      animate={isLive ? { x: [-100, 0] } : {}}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    />
                  </motion.svg>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-[10px] font-mono uppercase">Emotional State</span>
                <span className={cn(
                  "text-[9px] px-2 py-0.5 rounded border uppercase font-mono font-bold tracking-widest",
                  (fridayMood === 'normal' || fridayMood === 'hasi') && "text-emerald-500 border-emerald-500/20 bg-emerald-500/5",
                  fridayMood === 'rag' && "text-red-500 border-red-500/20 bg-red-500/5",
                  fridayMood === 'oviman' && "text-blue-500 border-blue-500/20 bg-blue-500/5",
                  fridayMood === 'dostomi' && "text-amber-500 border-amber-500/20 bg-amber-500/5",
                )}>
                  {fridayMood}
                </span>
              </div>
              
              <div className="pt-6 mt-6 border-t border-white/5 space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-3 h-3 text-emerald-500/60" />
                  <h4 className="text-[9px] font-mono text-white/40 uppercase tracking-widest">Neural Diagnostics</h4>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="text-[8px] font-mono text-white/20 uppercase">Uptime</div>
                    <div className="text-xs font-mono text-white/80">{diagnosticInfo.uptime}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[8px] font-mono text-white/20 uppercase">Neural Nodes</div>
                    <div className="text-xs font-mono text-white/80">{diagnosticInfo.neuralNodes} Active</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[8px] font-mono text-white/20 uppercase">Memory Load</div>
                    <div className="text-xs font-mono text-white/80">{diagnosticInfo.memoryLoad}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-[8px] font-mono text-white/20 uppercase">Link Integrity</div>
                    <div className="text-xs font-mono text-emerald-500">{diagnosticInfo.linkIntegrity.toFixed(1)}%</div>
                  </div>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-white/5">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-[9px] font-mono text-white/30 uppercase tracking-widest">Neural Core Visualization</div>
                  <div className="flex gap-1">
                    <div className={cn("w-1 h-1 rounded-full animate-pulse", isLive ? "bg-emerald-500" : "bg-white/10")} />
                  </div>
                </div>
                <div className="relative aspect-square bg-black/40 rounded-2xl border border-white/5 overflow-hidden flex items-center justify-center group">
                  <div className="absolute inset-0 opacity-20">
                    <div className="grid grid-cols-8 h-full">
                      {[...Array(8)].map((_, i) => (
                        <div key={i} className="border-r border-white/10 h-full" />
                      ))}
                    </div>
                    <div className="grid grid-rows-8 w-full absolute inset-0">
                      {[...Array(8)].map((_, i) => (
                        <div key={i} className="border-b border-white/10 w-full" />
                      ))}
                    </div>
                  </div>
                  
                  {/* Core Animation */}
                  <div className="relative w-32 h-32">
                    <motion.div 
                      animate={{ 
                        rotate: 360,
                        scale: isThinking ? [1, 1.1, 1] : 1
                      }}
                      transition={{ 
                        rotate: { repeat: Infinity, duration: 10, ease: "linear" },
                        scale: { repeat: Infinity, duration: 0.5 }
                      }}
                      className={cn(
                        "absolute inset-0 border-2 border-dashed rounded-full transition-colors duration-500",
                        isLive ? "border-emerald-500/30" : "border-white/10"
                      )}
                    />
                    <motion.div 
                      animate={{ 
                        rotate: -360,
                        scale: isThinking ? [1, 1.2, 1] : 1
                      }}
                      transition={{ 
                        rotate: { repeat: Infinity, duration: 15, ease: "linear" },
                        scale: { repeat: Infinity, duration: 0.8 }
                      }}
                      className={cn(
                        "absolute inset-4 border border-dashed rounded-full transition-colors duration-500",
                        isLive ? "border-emerald-500/20" : "border-white/5"
                      )}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className={cn(
                        "w-4 h-4 rounded-full blur-md transition-colors duration-500",
                        isLive ? "bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.8)]" : "bg-white/10"
                      )} />
                      <motion.div 
                        animate={isLive ? {
                          scale: [1, 1.5, 1],
                          opacity: [0.3, 0.6, 0.3]
                        } : {}}
                        transition={{ repeat: Infinity, duration: 2 }}
                        className={cn(
                          "absolute w-12 h-12 rounded-full border transition-colors duration-500",
                          isLive ? "border-emerald-500/40" : "border-white/10"
                        )}
                      />
                    </div>
                  </div>
                  
                  {/* Data Stream Overlay */}
                  <div className="absolute bottom-2 left-2 right-2 flex justify-between text-[6px] font-mono text-white/20 uppercase tracking-widest">
                    <span>Core_Temp: 32.4°C</span>
                    <span>Sync_Lock: {isLive ? 'STABLE' : 'LOST'}</span>
                  </div>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-white/5">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-[9px] font-mono text-white/30 uppercase tracking-widest">Neural Core Metrics</div>
                  <div className="flex gap-1">
                    <div className="w-1 h-1 bg-emerald-500/50 rounded-full animate-pulse" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-6">
                  <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                    <div className="text-[8px] font-mono text-white/40 uppercase mb-1">Sync Stability</div>
                    <div className={cn(
                      "text-xs font-mono transition-colors",
                      syncStability > 99 ? "text-emerald-500" : "text-amber-500"
                    )}>
                      {isLive ? `${syncStability.toFixed(1)}%` : 'OFFLINE'}
                    </div>
                  </div>
                  <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                    <div className="text-[8px] font-mono text-white/40 uppercase mb-1">Latency</div>
                    <div className={cn(
                      "text-xs font-mono transition-colors",
                      neuralLatency < 30 ? "text-emerald-500" : "text-amber-500"
                    )}>
                      {isLive ? `${neuralLatency.toFixed(0)}ms` : 'N/A'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions / App Control */}
          <div className="bg-[#151619] rounded-3xl border border-white/5 p-6">
            <h3 className="text-xs font-mono text-emerald-500 uppercase tracking-[0.2em] mb-4">Neural Link Control</h3>
            <div className="grid grid-cols-1 gap-3 mb-6">
              <button 
                onClick={toggleLive}
                className={cn(
                  "w-full py-3 rounded-2xl font-mono text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-3 border",
                  isLive 
                    ? "bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20" 
                    : "bg-emerald-500/10 border-emerald-500/20 text-emerald-500 hover:bg-emerald-500/20"
                )}
              >
                {isLive ? <ZapOff className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
                {isLive ? "Terminate Neural Link" : "Establish Neural Link"}
              </button>
            </div>

            <h3 className="text-xs font-mono text-emerald-500 uppercase tracking-[0.2em] mb-4">Device Access</h3>
            <div className="grid grid-cols-2 gap-3 mb-6">
              <a 
                href="https://wa.me/" 
                target="_blank" 
                rel="noreferrer"
                className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-emerald-500 hover:text-black transition-all group"
              >
                <MessageCircle className="w-6 h-6 mb-2" />
                <span className="text-[10px] font-mono uppercase">WhatsApp</span>
              </a>
              <a 
                href="https://youtube.com" 
                target="_blank" 
                rel="noreferrer"
                className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-red-500 hover:text-white transition-all"
              >
                <Youtube className="w-6 h-6 mb-2" />
                <span className="text-[10px] font-mono uppercase">YouTube</span>
              </a>
            </div>

            <h3 className="text-xs font-mono text-emerald-500 uppercase tracking-[0.2em] mb-4">System Simulation</h3>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={async () => {
                  if (user) {
                    try {
                      await addDoc(collection(db, 'calls'), {
                        callerName: 'Sadaf\'s Friend',
                        timestamp: new Date().toISOString(),
                        status: 'incoming',
                        userId: user.uid
                      });
                    } catch (err) {
                      handleFirestoreError(err, OperationType.WRITE, 'calls');
                    }
                  }
                }}
                className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-emerald-500 hover:text-black transition-all group"
              >
                <Phone className="w-6 h-6 mb-2 text-white/40 group-hover:text-black" />
                <span className="text-[10px] font-mono uppercase">Simulate Call</span>
              </button>
              <button 
                onClick={async () => {
                  if (user) {
                    try {
                      await addDoc(collection(db, 'messages'), {
                        senderName: 'Sadaf\'s Friend',
                        platform: 'WhatsApp',
                        content: 'Hey Sadaf, are we still meeting today?',
                        timestamp: new Date().toISOString(),
                        status: 'unread',
                        userId: user.uid
                      });
                    } catch (err) {
                      handleFirestoreError(err, OperationType.WRITE, 'messages');
                    }
                  }
                }}
                className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-emerald-500 hover:text-black transition-all group"
              >
                <MessageSquare className="w-6 h-6 mb-2 text-white/40 group-hover:text-black" />
                <span className="text-[10px] font-mono uppercase">Simulate Msg</span>
              </button>
            </div>
          </div>

          {/* Memory Card */}
          <div className="bg-[#151619] rounded-3xl border border-white/5 p-6">
            <h3 className="text-xs font-mono text-emerald-500 uppercase tracking-[0.2em] mb-4">Memory Bank</h3>
            <div className="space-y-3">
              {userProfile?.learnedTraits?.length > 0 ? (
                userProfile.learnedTraits.map((trait: string, i: number) => (
                  <div key={i} className="flex items-center gap-3 text-xs text-white/60 bg-white/5 p-2 rounded-lg">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                    {trait}
                  </div>
                ))
              ) : (
                <div className="text-xs text-white/20 italic text-center py-4">
                  Friday is still learning about you...
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Footer Status */}
      <footer className={cn(
        "h-8 text-black flex items-center px-6 text-[10px] font-mono font-bold uppercase tracking-widest fixed bottom-0 w-full z-50 transition-colors duration-500",
        (fridayMood === 'normal' || fridayMood === 'hasi') && "bg-emerald-500",
        fridayMood === 'rag' && "bg-red-500",
        fridayMood === 'oviman' && "bg-blue-500",
        fridayMood === 'dostomi' && "bg-amber-500",
      )}>
        <div className="flex items-center gap-4">
          <span>Neural Link: {isLive ? 'STABLE' : 'OFFLINE'}</span>
          <span className="opacity-50">|</span>
          <span>Encryption: AES-256</span>
          <span className="opacity-50">|</span>
          <span>Friday AI OS v2.5.0-STABLE</span>
        </div>
      </footer>
        </div>
      </div>
    </ErrorBoundary>
  );
}
